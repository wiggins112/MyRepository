module.exports = [{
    'delay': 500,
    'response': {
        'resCode': 0,
        'msg': null,
        'data': 'Mock data received!'
    }
}]
