const test = process.env.NODE_ENV === 'prodtest';
const debug = process.env.NODE_ENV === 'production' ? false : !test;
const prod = process.env.NODE_ENV === 'production';

const Bizhihui_Url = 'https://www.bizhihui.vip';

// 线上
const API_BaseUrl_Prod = 'https://appapi.bizhihui.info';
// 测试
const API_BaseUrl_Test = 'http://test.appapi.bizhihui.pro';
// 本地
const API_BaseUrl_Dev = 'http://10.0.0.10:8863';

// const API_BaseUrl = API_BaseUrl_Test;
const API_BaseUrl = debug ? API_BaseUrl_Dev : (test ? API_BaseUrl_Test : API_BaseUrl_Prod);

console.log('API_BaseUrl', API_BaseUrl);

const QINIU_CDN = 'https://ganlan-cdn.bizhihui.vip'; // ganlanCdn

const Iconfont = 'bmlocal://iconfont/fonts/icomoon.ttf';

const CHANNEL = 'default';
// const CHANNEL = 'test';
// const CHANNEL = 'uc';
// const CHANNEL = '360';
// const CHANNEL = 'xiaomi';
// const CHANNEL = 'baidu';
// const CHANNEL = 'huawei';
// const CHANNEL = 'sogou';
// const CHANNEL = 'lenovo'; // 联想
// const CHANNEL = 'vivo';
// const CHANNEL = 'oppo';
// const CHANNEL = 'gionee'; // 金立
// const CHANNEL = 'eoemarket'; // 优亿市场
// const CHANNEL = 'wostore'; // 沃商店
// const CHANNEL = 'anzhi'; // 安智市场
// const CHANNEL = 'mumayi'; // 木蚂蚁
// const CHANNEL = 'gfan'; // 机锋市场

// const CHANNEL = 'yingyongbao';

// ios 渠道
// const CHANNEL = 'appstore';
// const CHANNEL = 'fir';
// const CHANNEL = 'pgyer';

const diff_proxy = QINIU_CDN + '/app/diff/ganlan_bc_app/'; // 热更新包下载接口
console.log('diff_proxy', diff_proxy);

const bundleUpdate = `${API_BaseUrl}/api/tools/app/check`; // 热更新检查接口
console.log('bundleUpdate', bundleUpdate);

const UM_KEY_ANDROID = '5b20ee70f43e4869800000e4'; // 安卓 正式
const UM_KEY_iOS = '5b20e1698f4a9d5efd000012'; // iOS 正式

const Token_Website = prod ? 'https://i.bizhihui.vip' : 'http://i.test.bizhihui.vip'; // 糖果官网

const APP_NAME = 'ganlan_bc_app';

const TENCENT_CAPTCHA = { APP_ID: '2012623632' }

module.exports.test = test;
module.exports.debug;
module.exports.Bizhihui_Url = Bizhihui_Url;
module.exports.API_BaseUrl = API_BaseUrl;
module.exports.QINIU_CDN = QINIU_CDN;
module.exports.CHANNEL = CHANNEL;
module.exports.diff_proxy = diff_proxy;
module.exports.bundleUpdate = bundleUpdate;
module.exports.Iconfont = Iconfont;
module.exports.UM_KEY_ANDROID = UM_KEY_ANDROID;
module.exports.UM_KEY_iOS = UM_KEY_iOS;
module.exports.Token_Website = Token_Website;
module.exports.APP_NAME = APP_NAME;
module.exports.TENCENT_CAPTCHA = TENCENT_CAPTCHA;
module.exports.STATIC_SERVER = API_BaseUrl + '/static';
module.exports.language = 'ind'

// module.exports.STATIC_SERVER = 'http://10.0.0.104:3000/static';
