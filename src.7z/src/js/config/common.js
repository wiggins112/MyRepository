const bmPush = weex.requireModule('bmPush')
const storage = weex.requireModule('bmStorage');
const axios = weex.requireModule('bmAxios');
const modal = weex.requireModule('modal')
const bmWXShare = weex.requireModule('bmWXShare')
const globalEvent = weex.requireModule('globalEvent')
const bmRouter = weex.requireModule('bmRouter');
const bmUMAnalytics = weex.requireModule('bmUMAnalytics');
const bmBundleUpdate = weex.requireModule('bmBundleUpdate')

import _ from 'lodash'
import MD5 from 'blueimp-md5'
import { API_BaseUrl, UM_KEY_ANDROID, UM_KEY_iOS, CHANNEL, bundleUpdate, APP_NAME } from './config'

export default {
    StorageKey: {
        task_dialogs: 'task_dialogs',
    },
    initPush(user_token) {
        return new Promise((resolve, reject) => {
            if (!user_token) {
                user_token = storage.getDataSync('user_token').data;
                user_token = user_token ? JSON.parse(user_token) : '';
                if (!user_token) {
                    resolve();
                    return;
                }
            }
            console.log('initPush');
            bmPush.initPush({
                appId: 'kxGODFzsI28RCE8z0bAMD5',
                appKey: 'HduFAPMhpr7tKenszXE0m5',
                appSecret: 'YebB9MoRJqAoL70MaT82J2'
            });
            bmPush.getCid(result => {
                if (!result || !result.data || !result.data.cid) {
                    resolve();
                    return;
                }
                axios.fetch({
                    url: `${API_BaseUrl}/api/user_config/notice`,
                    name: 'putUserConfigNotice',
                    method: 'PUT',
                    data: { device: { cid: result.data.cid, os: weex.config.env.platform, type: 'getui' } },
                    header: { Cookie: `token=${user_token}` }
                }, (resData) => {
                    console.log('put cid success:', result.data.cid);
                    resolve();
                });
            });
        })
    },
    initUM() {
        return new Promise((resolve, reject) => {
            let platform = weex.config.env.platform;
            if (platform === 'iOS') {
                bmWXShare.initUM(UM_KEY_iOS);
            } else {
                // android
                bmWXShare.initUMShare(UM_KEY_ANDROID, CHANNEL);
            }
            resolve();
        })
    },
    initUMAppStat() {
        return new Promise((resolve, reject) => {
            let platform = weex.config.env.platform;
            if (platform === 'iOS') {
                bmUMAnalytics.initUM(UM_KEY_iOS);
            } else {
                // android
                bmUMAnalytics.initUMStat(UM_KEY_ANDROID, CHANNEL);
                // modal.toast({ message: 'umeng: ' + platform + UM_KEY_ANDROID + CHANNEL, duration: 3 })
            }
            resolve();
        })
    },
    // 初始化微信
    initWX() {
        return new Promise((resolve, reject) => {
            bmWXShare.initWX({
                appKey: 'wx3d87b0a1c9f9c3ba', // 微信开发平台申请的appkey
                appSecret: '6e726d1ecb95606888d234d768b00af8', // appKey对应的appSecret，
                redirectURL: '' // 授权回调页面
            })
            resolve();
        })
    },
    // 初始化新浪微博
    initWeibo() {
        return new Promise((resolve, reject) => {
            bmWXShare.initWX({
                Platform: 'sinaWeibo',
                appKey: 'wx3d87b0a1c9f9c3ba', // 微信开发平台申请的appkey
                appSecret: '6e726d1ecb95606888d234d768b00af8', // appKey对应的appSecret，
                redirectURL: '' // 授权回调页面
            })
            resolve();
        })
    },
    initDbBackExit(unback_exit) {
        let curHomeBackTriggerTimes = 0;
        let maxHomeBackTriggerTimes = 2;
        globalEvent.addEventListener('homeBack', options => {
            if (unback_exit) {
                bmRouter.finish();
                return;
            }
            curHomeBackTriggerTimes++;
            if (curHomeBackTriggerTimes == 1) {
                modal.toast({ message: `再按一次退出程序` })
            }
            if (curHomeBackTriggerTimes === maxHomeBackTriggerTimes) {
                bmRouter.finish()
            }
            setTimeout(() => {
                curHomeBackTriggerTimes--;
            }, 800);
        })
    },
    calculateParamsSign(params) {
        let key_value_arr = [];
        for (let key in params) {
            if (key === '_s') {
                continue;
            }
            key_value_arr.push({ key, value: params[key] })
        }
        let sorted_key_value_arr = _.sortBy(key_value_arr, 'key');
        let concat_str = sorted_key_value_arr.map(i => {
            return String(i.value === undefined ? '' : i.value);
        }).join('');
        let sign = MD5(concat_str);
        return sign;
    },
    initHotUpdate() {
        bmBundleUpdate.getJsVersion(version => {
            // 直接返回版本号，如果取不到会返回空的字符串
            axios.fetch({
                url: bundleUpdate,
                method: 'GET',
                data: {
                    jsVersion: version,
                    appName: APP_NAME,
                    isDiff: 0,
                    [weex.config.env.platform]: weex.config.env.appVersion,
                    customBundleUpdate: 1,
                },
            }, (resData) => {
                if (resData.data.resCode === 0) {
                    console.log('initHotUpdate start', resData.data.data.path, resData.data.data.diff, '');
                    // 包下载的地址
                    bmBundleUpdate.download({
                        path: resData.data.data.path, // jsbundle zip包下载地址
                        diff: resData.data.data.diff // 是否下载差分包
                    }, resData => {
                        console.log('initHotUpdate resData2', resData);
                        bmBundleUpdate.update();
                    })
                }
            });
        });
    },
    addUmengClickEvent(event_name) {
        // 友盟统计-自定义事件计数
        if (bmUMAnalytics.umengClick) {
            bmUMAnalytics.umengClick(event_name);
        }
    }

}
