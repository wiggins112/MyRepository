// const language = 'zh-CN'
// const language = 'ind'

const hide = {
    ind: ['Stare', 'BetMy', 'TaskCenter', 'ExtractBzh', 'Airdrop', 'NewsChosen', 'NewsNew', 'NewsNotice', 'NewsWeibo', 'NewsTeach']
}

module.exports = { hide }