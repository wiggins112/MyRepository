<template>
    <div class="container">
        <div class="wrapper" :style="{visibility: (!showPoster && loade_page) ? 'visible' : 'hidden' }">
            <wxc-tab-bar ref="wxc-tab-bar" :tab-titles="tabTitles" :tab-styles="tabStyles" duration="0" title-type="icon" @wxcTabBarCurrentTabSelected="wxcTabBarCurrentTabSelected">
                <div class="item_container" :style="contentStyle">
                    <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
                    <Stat :tabbarActive="curentActiveTabbar.title === '自选' ? true : false" @SetTabbarActive="SetTabbarActive"></Stat>
                </div>
                <div class="item_container" :style="contentStyle">
                    <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
                    <Coins :tabbarActive="curentActiveTabbar.title === '行情' ? true : false" :activeNavTab="activeNavTab" @SetTabbarActive="SetTabbarActive"></Coins>
                </div>
                <div class="item_container" :style="contentStyle">
                    <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
                    <SelectCoin :tabbarActive="curentActiveTabbar.title === '选币' ? true : false" @SetTabbarActive="SetTabbarActive"></SelectCoin>
                </div>
                <div class="item_container" :style="contentStyle">
                    <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
                    <News :tabbarActive="curentActiveTabbar.title === '资讯' ? true : false"></News>
                </div>
                <div class="item_container" :style="contentStyle">
                    <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
                    <Settings :tabbarActive="curentActiveTabbar.title === '我的' ? true : false" @SetTabbarActive="SetTabbarActive"></Settings>
                </div>
            </wxc-tab-bar>
        </div>
        <DialogSoftUpdate :show="dialog_update_show"  :update_info="update_info" @closeDialog="DialogCancelUpdate" @ConfirmBtnClicked="DialogConfirmUpdate" >
        </DialogSoftUpdate>
        <BzhPoster :showPoster="showPoster && loade_page" @closePoster="closePoster" />
        <DialogRedPacket v-if="show_packet" @closePacket="closePacket"></DialogRedPacket>
    </div>
</template>
<script>
import { WxcTabBar, Utils, WxcButton } from 'weex-ui';
import News from './News.vue';
import Coins from './Coins.vue';
import Stat from './Stat.vue';
import Settings from './Settings.vue';
import SelectCoin from './SelectCoin.vue';
import StatusBar from '../components/StatusBar.vue'
import common from '../config/common';
import Dialog from '../components/Dialog.vue'
import BzhPoster from '../components/BzhPoster.vue'
import DialogRedPacket from '../components/DialogRedPacket.vue'
import DialogSoftUpdate from '../components/DialogSoftUpdate.vue'
import {Iconfont} from '../config/config.js'


export default {
    components: {
        WxcTabBar,
        WxcButton,
        Stat,
        News,
        StatusBar,
        SelectCoin,
        Coins,
        Dialog,
        BzhPoster,
        Settings,
        DialogRedPacket,
        DialogSoftUpdate,
    },
    data() {
        return {
            show_packet: false,
            dialog_update_show: false,
            showPoster: true,
            update_info: {},
            loade_page: false,
            statusBarStyle: {
                bgColor: '#ffffff',
            },
            touchBarHeight: weex.config.eros.touchBarHeight ? weex.config.eros.touchBarHeight : 20,
            tabTitles: [{
                    title: '自选',
                    icon: `bmlocal://assets/images/stat.png`,
                    activeIcon: `bmlocal://assets/images/stat_active.png`,
                    dot: false, // 是否显示小红点
                    clickType: 'bzh_bottomnavi_chosen_click'
                }, {
                    title: '行情',
                    icon: `bmlocal://assets/images/market.png`,
                    activeIcon: `bmlocal://assets/images/market_active.png`,
                    dot: false,
                    clickType: 'bzh_bottomnavi_market_click'
                }, {
                    title: '选币',
                    icon: `bmlocal://assets/images/guide.png`,
                    activeIcon: `bmlocal://assets/images/guide_active.png`,
                    dot: false,
                    clickType: 'bzh_bottomnavi_choose_click'
                }, {
                    title: '资讯',
                    icon: `bmlocal://assets/images/news.png`,
                    activeIcon: `bmlocal://assets/images/news_active.png`,
                    dot: false,
                    clickType: 'bzh_bottomnavi_news_click'
                }, {
                    title: '我的',
                    icon: `bmlocal://assets/images/mine.png`,
                    activeIcon: `bmlocal://assets/images/mine_active.png`,
                    dot: false,
                    clickType: 'bzh_bottomnavi_mine_click'
                }],
            curentActiveTabbar: {},
            contentStyle: '',
            tabStyles: {
                bgColor: '#FFFFFF',
                titleColor: '#434343',
                activeTitleColor: '#F7B237',
                activeBgColor: '#FFFFFF',
                isActiveTitleBold: true,
                iconWidth: 50,
                iconHeight: 50,
                width: 160,
                height: 100,
                fontSize: 22,
                textPaddingLeft: 10,
                textPaddingRight: 10
            },
            user_info: {},
            unview_num: 0,
            activeNavTab: 0,
        };
    },
    eros: {
        beforeBackAppear(params, options) {
            this.getUserInfo();
        },
    },
    beforeCreate() {
        var domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont2",
            'src': `url('${Iconfont}')`
        });
    },
    created() {
        this.$navigator.setNavigationInfo({
            statusBarStyle: 'Default'
        });
        this.getRouterParams();
        this.init();
    },
    watch: {
        'showPoster': {
            handler(newValue) {
                if (!newValue) {
                    this.getToolsAppVersion();
                    this.getUserTokenDailyStat();
                    // common.initHotUpdate();
                }
            },
            deep: true,
        },
    },
    methods: {
        init() {
            this.getUserInfo();
            this.SetCurrentTabbarActive();
            this.initTabBar();
            this.getUserBets();
            common.initUM();
            common.initUMAppStat();
            common.initPush();
        },
        getRouterParams() {
            this.$router.getParams().then(resData => {
                resData = resData || {};
                this.loade_page = true;
                this.showPoster = resData.hide_poster ? false : true;
                let tab = resData.tab || 0;
                this.$refs['wxc-tab-bar'].setPage(tab);
                // 安卓自定义退出 app
                common.initDbBackExit(resData.unback_exit);
            })
        },
        closePacket() {
            this.show_packet = false;
        },
        getUserBets() {
            if (!this.user_info.is_login) {
                return;
            }
            let params = {};
            params.items = 0;
            this.$fetch({
                name: 'getUserBets',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.unview_num = resData.unview;
                    if (this.unview_num > 0) {
                        this.tabTitles[4].dot = true;
                    } else {
                        this.tabTitles[4].dot = false;
                    }
                }
            }).catch((e) => {

            });
        },
        getUserTokenDailyStat() {
            let params = {};
            this.$fetch({
                name: 'getUserTokenDailyStat',
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    // 可以领取红包，且没有领取过
                    if (resData.result.can_get_redpacket && !resData.result.done_daily_redpacket) {
                        this.show_packet = true;
                    }
                } else {
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((e) => {
                console.log(e.message);
            });
        },
        initTabBar() {
            // const tabPageHeight = Utils.env.getPageHeight();
            // If the page doesn't have a navigation bar
            let tabPageHeight = Utils.env.deviceHeight / Utils.env.deviceWidth * 750;
            this.contentStyle = { height: (tabPageHeight - this.tabStyles.height) + 'px' };
            if (weex.config.env.platform === 'iOS') {
                this.contentStyle = '';
            }
        },
        closePoster() {
            setTimeout(() => {
                this.showPoster = false;
            }, 100)
        },
        DialogCancelUpdate() {
            this.dialog_update_show = false;
        },
        DialogConfirmUpdate() {
            if (!this.update_info.force) {
                this.dialog_update_show = false;
            }
        },
        getToolsAppVersion() {
            let params = {};
            params.versioncode = weex.config.env.appVersion;
            params.platform = weex.config.env.platform;
            params.app_name = weex.config.env.appName;
            this.$fetch({
                name: 'getToolsAppVersion',
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.update_info = resData.result;
                    if (resData.result.update) {
                        this.dialog_update_show = true;
                    }
                }
            }).catch((e) => {
                console.log(e.message)
            });
        },
        wxcTabBarCurrentTabSelected(e) {
            const index = e.page;
            this.curentActiveTabbar = this.tabTitles[index];
            this.getUserBets();
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent(this.curentActiveTabbar.clickType || 'bzh_bottomnav');
        },
        SetTabbarActive(index, tab) {
            this.$refs['wxc-tab-bar'].setPage(index)
            this.activeNavTab = tab || 0;
        },
        getUserInfo() {
            this.user_info = this.$storage.getSync('user_info') || {};
        },
        SetCurrentTabbarActive() {
            if (!this.user_info.is_login) {
                setTimeout(() => {
                    this.$refs['wxc-tab-bar'].setPage(2)
                }, 100)
            }
        },
    },
    computed: {

    }
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');

.wrapper {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
}

.status_bar {
    height: 40;
    background-color: @base_color;
}

.item_container {
    width: 750px;
    background-color: @bgf4f5f6;
    overflow: auto;
}

.icon {
    font-family: iconfont2;
}

</style>
