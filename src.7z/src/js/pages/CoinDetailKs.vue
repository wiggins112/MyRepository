<template>
    <div class="container">
        <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
        <wxc-minibar :title="title">
            <!-- <text slot="right" class="icon right_icon" @click="minibarRightButtonClick">&#xe90b;</text> -->
        </wxc-minibar>
        <list class="wrapper_scroller" ref="ks_list" loadmoreoffset="50" @loadmore="loadmore" :style="{height: tabPageHeight}">
            <cell class="box_hd">
                <div class="list">
                    <div class="item item_price">
                        <text :class="['top_special', 'price_cny', handicap.price_change_8h_percent > 0 ? 'safe' : 'warn']">{{handicap.cur_price_unit_str || '--'}}</text>
                    </div>
                    <div class="item item_24price">
                        <text class="top">24h最高</text>
                        <text class="bottom">{{handicap.max_price_unit_24h_str || '--'}}</text>
                    </div>
                    <div class="item">
                        <text class="top">买一价</text>
                        <text class="bottom">{{handicap.buy_price_unit_str || '--'}}</text>
                    </div>
                    <div class="item">
                        <text class="top">振幅</text>
                        <text class="bottom">{{handicap.amplitude_percent_str || ''}}</text>
                    </div>
                    <div class="item item_info" @click="jumpCoinExplain('zhenfu')">
                        <text class="icon icon_mark">&#xe936;</text>
                    </div>
                </div>
                <div class="list list_bottom">
                    <div class="item item_price">
                        <div class="bottom">
                            <text :class="['bottom_special', handicap.price_change_8h_percent > 0 ? 'safe' : 'warn']">{{String(handicap.price_unit_change_8h_str || '').replace('¥', '')}}</text>
                            <text :class="['bottom_special', 'percent_change', handicap.price_change_8h_percent > 0 ? 'safe' : 'warn']">{{String(handicap.price_change_8h_percent_str || '')}}</text>
                        </div>
                    </div>
                    <div class="item item_24price">
                        <text class="top">24h最低</text>
                        <text class="bottom">{{handicap.min_price_unit_24h_str || '--'}}</text>
                    </div>
                    <div class="item">
                        <text class="top">卖一价</text>
                        <text class="bottom">{{handicap.sale_price_unit_str || '--'}}</text>
                    </div>
                    <div class="item">
                        <text class="top">量比</text>
                        <text class="bottom">{{handicap.quantity_ratio_percent_str || '--'}}</text>
                    </div>
                    <div class="item item_info" @click="showDialog">
                        <text class="icon icon_mark">&#xe937;</text>
                    </div>
                </div>
            </cell>
            <cell class="box_bd">
                <div class="k_wrap">
                    <Ks @unitChange="unitChange"></Ks>
                </div>
                <div class="coin_flow">
                    <CoinCashFlow :is_loadmore="is_loadmore" @Loadmoreing="Loadmoreing"></CoinCashFlow>
                </div>
            </cell>
        </list>
        <div class="btn_box">
            <div class="btn_item btn_F10" @click="jumpCoinDetail">
                <div class="logo_image">
                    <image class="logo_image" resize="cover" :src="coin.icon || default_coin_icon"></image>
                </div>
                <text class="symbol_text">{{router_params.symbol}}详情</text>
            </div>
            <div class="btn_item" @click="jumpToWeb" v-if="config_platform.enable">
                <text class="icon icon_btn">&#xe939;</text>
                <text class="symbol_text">交易所</text>
            </div>
            <div class="btn_item" @click="addUserCoin" >
                <text class="icon icon_btn" v-if="selected.is_star">&#xe90a;</text>
                <text class="icon icon_btn" v-if="!selected.is_star">&#xe93a;</text>
                <text class="symbol_text">自选</text>
            </div>
            <div class="btn_item" @click="jumpCoinStat" v-if="!hideModule['Stare']">
                <text class="icon icon_btn">&#xe93c;</text>
                <text class="symbol_text">盯盘</text>
            </div>
        </div>
        <Dialog title="" dialogWidth="650" left="50" :show="true" dialogBoxBgColor="transparent" top="300" v-if="is_show_dialog">
            <div slot class="dialog_box">
                <div class="dialog_hd">
                    <div class="dialog_title" @click="jumpCoinExplain('pankoushuju')">
                        <text class="dialog_title_text">盘口数据</text>
                        <text class="icon icon_mark icon_mark_pankou">&#xe936;</text>
                    </div>
                    <div class="dialog_close" @click="closeDialog">
                        <text class="icon icon_close">&#xe91a;</text>
                    </div>
                </div>
                <div class="dialog_bd">
                    <div class="dialog_list">
                        <div class="dialog_item">
                            <div class="item_info_table">
                                <div class="info_table_hd">
                                    <div class="table_item">
                                        <text class="table_name">成交量</text>
                                        <text class="table_text">{{handicap.today_volume_count_str || '--'}}</text>
                                    </div>
                                    <div class="table_item">
                                        <text class="table_name">成交额</text>
                                        <text class="table_text">{{handicap.today_trade_count_price_unit_str || '--'}}</text>
                                    </div>
                                </div>
                                <div class="info_table_bd">
                                    <div class="table_item">
                                        <text class="table_name">内盘</text>
                                        <text class="table_text warn">{{handicap.is_sell_amount_str || '--'}}</text>
                                    </div>
                                    <div class="table_item">
                                        <text class="table_name">外盘</text>
                                        <text class="table_text safe">{{handicap.is_buy_amount_str || '--'}}</text>
                                    </div>
                                </div>
                            </div>
                            <div class="item_info_table">
                                <div class="info_table_hd">
                                    <div class="table_item">
                                        <text class="table_name">委比</text>
                                        <text :class="['table_text', handicap.delegate_ratio_percent > 0 ? 'safe' : 'warn']">{{handicap.delegate_ratio_percent_str || '--'}}</text>
                                    </div>
                                    <div class="table_item">
                                        <text class="table_name">涨速</text>
                                        <text :class="['table_text', handicap.rising_speed_5m_price_unit > 0 ? 'safe' : 'warn']">{{handicap.rising_speed_5m_str || '--'}}</text>
                                    </div>
                                </div>
                                <div class="info_table_bd">
                                    <div class="table_item">
                                        <text class="table_name">换手率</text>
                                        <text class="table_text">{{handicap.turnover_Rate_percent_str || '--'}}</text>
                                    </div>
                                    <div class="table_item">
                                        <text class="table_name">24h涨幅</text>
                                        <text :class="['table_text', handicap.rising_speed_24_percent > 0 ? 'safe' : 'warn']">{{handicap.rising_speed_24_percent_str || '--'}}</text>
                                    </div>
                                </div>
                            </div>
                            <div class="item_info_table item_info_table_noborder">
                                <div class="info_table_hd">
                                    <div class="table_item">
                                        <text class="table_name">实际价</text>
                                        <text class="table_text">{{handicap.real_price_unit_str || '--'}}</text>
                                    </div>
                                </div>
                                <div class="info_table_bd">
                                    <div class="table_item">
                                        <text class="table_name">手续费</text>
                                        <text class="table_text">{{handicap.platform_fee_price_unit_str || '--'}}</text>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Dialog>
    </div>
</template>
<script>
import { Utils, WxcButton } from 'weex-ui';
import { buiTabbar } from 'bui-weex'
import WxcMinibar from '../components/WxcMinibar.vue'
import StatusBar from '../components/StatusBar.vue'
import Ks from '../components/Ks.vue'
import CoinCashFlow from '../components/CoinCashFlow .vue'
import Loadmore from '../components/Loadmore.vue'
import Refresher from '../components/Refresher.vue'
import Dialog from '../components/Dialog.vue'
import { API_BaseUrl, Iconfont } from '../config/config.js'
import utils from '../config/utils'
import common from '../config/common';
export default {
    components: {
        WxcMinibar,
        WxcButton,
        StatusBar,
        buiTabbar,
        Ks,
        Loadmore,
        Refresher,
        CoinCashFlow,
        Dialog
    },
    data() {
        return {
            hideModule: this.$storage.getSync('hideModule') || {},
            title: '',
            default_coin_icon: `bmlocal://assets/images/default_coin_icon.png`,
            router_params: {},
            statusBarStyle: {
                bgColor: '#ffffff',
            },
            coin: {},
            coin_ks: [],
            symbol: '',
            selected: {
                pair_symbol: '',
                pair_base: '',
                platform: '',
                is_star: false,
            },
            loading: {
                coin_ks: 'loading',
            },
            is_loadmore: false,
            is_show_dialog: false,
            handicap_raw: {},
            timeout_ts: 5000,
            interval_timmer: null,
            price_unit: {
                key: 'CNY'
            },
            config_platform: {
                enable: 0,
            },
        };
    },
    eros: {
        beforeBackAppear(params, options) {
            this.setIntervalData();
        },
        // app 前后台相关 start 
        appActive() {
            // 前台
        },
        appDeactive() {
            // 后台
            this.clearIntervalTimmer();
        },
        // app 前后台相关 end 
        beforeDisappear(options) {
            // 离开页面
            this.clearIntervalTimmer();
        }
    },
    beforeCreate() {
        var domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont2",
            'src': `url('${Iconfont}')`
        });
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.getConfig();
            this.getRouterParams();
        },
        addUserCoin() {
            if (this.selected.is_star) {
                this.deleteUserCoin();
            } else {
                this.postUserCoin();
            }
        },
        getConfig() {
            let params = {};
            params.type = 'app_config';
            params.key = 'app_func_switch';
            this.$fetch({
                name: 'getConfig',
                methods: 'GET',
                data: params,
            }).then((resData) => {
                if (resData.error === 0) {
                    this.config_platform = resData.result.coin_detail_platform || {};
                } else { 
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((err) => {
                console.error('getConfig', err);
                console.log(e.message)
            });
        },    
        getRouterParams() {
            this.$router.getParams().then(resData => {
                this.router_params = resData;
                this.symbol = resData.pair_symbol || resData.symbol;
                this.selected.pair_symbol = this.symbol;
                this.selected.pair_base = resData.pair_base;
                this.selected.platform = resData.platform;
                this.title = `${this.symbol}:${resData.pair_base}(${resData.platform})`;
                this.price_unit = this.$storage.getSync('tab_kl_unit') || { key: 'CNY' };
                this.getCoin();
                this.getCoinPair();
                this.getCoinHandicap();
                this.postUserTokenDailyReadCoin();
                this.setIntervalData();
            })
        },
        unitChange(unit) {
            this.price_unit = unit;
        },
        fixUnit(data, unit = 'CNY') {
            unit = String(unit).toLowerCase();
            for (let k in data) {
                let price_unit = 'price_' + unit;
                if (k.includes(price_unit)) {
                    let k_unit = k.replace(price_unit, 'price_unit');
                    data[k_unit] = data[k];
                }
            }
            console.log('handicap', data);
            return data;
        },
        showDialog() {
            this.is_show_dialog = true;
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent('bzh_cointrade_handicap_click');
        },
        closeDialog() {
            this.is_show_dialog = false;
        },
        postUserTokenDailyReadCoin() {
            let params = {};
            params.symbol_id = this.router_params.symbol_id;
            params.quote = this.selected.pair_symbol;
            params.base = this.selected.pair_base;
            params.platform = this.selected.platform;
            console.log(params);
            this.$fetch({
                name: 'postUserTokenDailyReadCoin',
                method: 'POST',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {

                } else {
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((e) => {
                console.log(e.message)
            });
        },
        minibarRightButtonClick() {},
        loadmore() {
            this.$refs.ks_list.resetLoadmore();
            this.is_loadmore = true;
        },
        Loadmoreing() {
            this.is_loadmore = false;
        },
        getCoin() {
            let params = {};
            params.symbol = this.symbol;
            this.$fetch({
                url: `${API_BaseUrl}/api/coin/${params.symbol}`,
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.coin = resData.result;
                } else {
                    this.$notice.toast({ message: resData.message });
                }
            }).catch((e) => {
                console.log(e.message);
            });
        },
        getCoinPair() {
            let params = {};
            params.platform = this.selected.platform;
            params.pair_base = this.selected.pair_base;
            params.pair_symbol = this.selected.pair_symbol;
            this.$fetch({
                name: 'getCoinPair',
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    resData.result.is_star ? resData.result.is_star = true : resData.result.is_star = false;
                    this.selected = resData.result;
                } else {
                    this.$notice.toast({ message: resData.message });
                }
            }).catch((e) => {
                console.log(e.message);
            });
        },
        getCoinHandicap() {
            let params = {};
            params.platform = this.selected.platform;
            params.pair_base = this.selected.pair_base;
            params.pair_symbol = this.selected.pair_symbol;
            params.unit = this.price_unit.key;
            this.$fetch({
                name: 'getCoinHandicap',
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.handicap_raw = resData.result || {};

                } else {
                    this.$notice.toast({ message: resData.message });
                }
            }).catch((e) => {
                console.log(e.message);
            });
        },
        postUserCoin() {
            let params = {
                platform: this.selected.platform,
                pair_symbol: this.selected.pair_symbol,
                pair_base: this.selected.pair_base,
                symbol_id: this.router_params.symbol_id,
            };
            if (this.selected.platform === '均价') {
                params.pair_symbol = this.selected.symbol || this.symbol;
                params.pair_base = '';
            }
            this.$notice.loading.show();
            this.$fetch({
                name: 'postUserCoin',
                method: 'POST',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.$notice.toast({ message: '已添加' })
                    this.selected.is_star = true;
                } else {
                    this.$notice.toast({ message: resData.message });
                }
                this.$notice.loading.hide()

            }).catch((e) => {
                console.log(e.message);
                this.$notice.loading.hide();
            });
        },
        deleteUserCoin() {
            let params = {
                platform: this.selected.platform,
                pair_symbol: this.selected.pair_symbol,
                pair_base: this.selected.pair_base,
                symbol_id: this.router_params.symbol_id,
            };
            if (this.selected.platform === '均价') {
                params.pair_symbol = this.selected.symbol || this.symbol;
                params.pair_base = '';
            }
            this.$notice.loading.show();
            let query_str = utils.getQueryStr(params);
            this.$fetch({
                url: `${API_BaseUrl}/api/user/coin?${encodeURI(query_str)}`,
                method: 'DELETE',
                data: {},
            }).then(resData => {
                if (resData.error === 0) {
                    this.$notice.toast({ message: '已取消' })
                    this.selected.is_star = false;
                } else {
                    this.$notice.toast({ message: resData.message });
                }
                this.$notice.loading.hide()

            }).catch((e) => {
                console.log(e.message);
                this.$notice.loading.hide();
            });
        },
        jumpCoinDetail() {
            let { symbol } = this.selected;
            let symbol_id = this.router_params.symbol_id;
            this.$router.open({
                name: 'CoinDetail',
                params: {
                    symbol,
                    symbol_id,
                }
            });
        },
        jumpCoinStat() {
            let { pair_base, pair_symbol, platform, symbol } = this.selected;
            let symbol_id = this.router_params.symbol_id;
            if (platform === '均价') {
                this.$router.open({
                    name: 'Stare',
                    params: {
                        symbol,
                        platform,
                        symbol_id,
                    }
                });
            } else {
                this.$router.open({
                    name: 'Stare',
                    params: {
                        symbol,
                        pair_base,
                        pair_symbol,
                        platform,
                        symbol_id,
                    }
                });
            }
        },
        jumpCoinExplain(name) {
            this.$router.open({
                name: 'CoinExplain',
                params: {
                    name: name,
                    pagename: 'CoinDetailKs',
                }
            })
        },
        jumpToWeb() {
            let urls = this.selected.website || '';
            if (!urls) {
                return;
            }
            this.$router.openBrowser(urls);
        },
        setIntervalData() {
            this.clearIntervalTimmer();
            this.interval_timmer = setInterval(() => {
                this.getCoinHandicap();
                this.getCoinPair();
            }, this.timeout_ts)
        },
        clearIntervalTimmer() {
            if (this.interval_timmer) {
                clearInterval(this.interval_timmer);
                this.interval_timmer = null;
            }
        },
    },
    computed: {
        tabPageHeight() {
            return Utils.env.getPageHeight();
        },
        handicap() {
            return this.fixUnit(this.handicap_raw, this.price_unit.key);
        }
    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.container {}

.icon {
    font-family: iconfont2;
}

.right_icon {
    font-size: 40px;
}

.wrapper_scroller {}

.box_hd {
    padding-left: @padding_size;
    padding-right: @padding_size;
    padding-top: 15px;
    padding-bottom: 15px;
    background-color: #fff;
    border-color: #eee;
    border-bottom-width: 1px;
}

.list {
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
}

.list_bottom {
    margin-top: 5px;
}

.item {
    flex: 2;
    flex-direction: column;
    margin-bottom: 7px;
}

.item_price {
    flex: 3.4;
}

.item_info {
    flex: 1;
}

.item_24price {
    flex: 2.5;
}

.top {
    color: #9b9da4;
    font-size: 20px;
}

.bottom {
    margin-top: 5px;
    color: #434343;
    font-size: 22px;
    font-weight: bold;
    flex-direction: row;
    align-items: center;
}

.icon_mark {
    text-align: left;
    font-size: 40px;
    color: #7A7A7A;
}

.icon_mark_pankou {
    padding-left: 15px;
}

.top_special {
    margin-top: 10px;
    font-size: 34px;
}

.bottom_special {
    margin-bottom: 10px;
    font-size: 22px;
}

.percent_change {
    padding-left: 15px;
}

.price_cny {
    text-align: left;
    font-weight: bold;
}

.price_usd {
    text-align: left;
}

.box_bd {
    background-color: #fff;
}

.btn_box {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    width: 750px;
    height: 98px;
    flex-direction: row;
    border-top-width: 2px;
    border-color: #eee;
    align-items: center;
    justify-content: center;
    background-color: #fff;
}

.btn_item {
    flex: 1;
    height: 78px;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    border-right-width: 1px;
    border-color: #eee;
}

.btn_item_free {
    background-color: #fff;
}

.btn_F10 {}

.btn_item_control {
    color: #fff;
    background-color: @main_color;
}

.warn {
    color: @warn_color;
}

.safe {
    color: @safe_color;
}

.safe_bg {
    background-color: @safe_color;
}

.warn_bg {
    background-color: @warn_color;
}

.coin_flow {
    padding-bottom: 300px;
}

.logo_image {
    width: 35px;
    height: 35px;
}

.symbol_text {
    padding-left: 10px;
    color: #434343;
}

.icon_btn {
    font-size: 40px;
    color: #434343;
}

.dialog_box {
    padding: 30px @padding_size;
    background-color: #fff;
    border-radius: 8px;
}

.dialog_hd {
    padding-bottom: 30px;
    flex-direction: row;
    align-items: center;
    border-bottom-width: 1px;
    border-color: #ddd;
}

.dialog_title {
    flex: 1;
    flex-direction: row;
    align-items: center;
}

.dialog_title_text {
    font-size: 26px;
    color: #434343;
}

.dialog_close {
    flex: 1;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
}

.icon_close {
    text-align: right;
    font-size: 40px;
    color: #434343;
}

.item_info_table {
    flex-direction: row;
    border-bottom-width: 1px;
    border-color: #E7EAF1;
}

.item_info_table_noborder {
    padding-top: 20px;
    border-bottom-width: 0px;
}

.info_table_hd {
    padding-right: 33px;
    flex: 1;
}

.info_table_bd {
    padding-left: 33px;
    flex: 1;
}

.table_item {
    height: 70px;
    flex-direction: row;
    align-items: center;
}

.table_name {
    color: #9B9DA4;
    font-size: 24px;
    text-align: left;
    flex: 2;
}

.table_text {
    font-size: 24px;
    text-align: right;
    color: #434343;
}

</style>
