<template>
    <div class="container">
        <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
        <wxc-minibar title="选币结果" >
            
        </wxc-minibar>
        <div class="wrapper">
            <scroller class="wrapper_scroller" loadmoreoffset="600" @loadmore="loadmoreCoin" offset-accuracy="100" @scroll="scrollHandler" :style="{ height: page_height}">
                <div class="filter_hd" v-if="route_query && route_query.length > 0">
                    <text class="filter_title">已选条件:</text>
                    <scroller class="filter_scroller" scroll-direction="horizontal" style="height: 80px;">
                        <div class="box_hd">
                            <div v-for="item in route_query" :key="item.name">
                                <text class="option" v-if="item.name">{{item.name}}：{{item.value}}</text>
                            </div>
                        </div>
                    </scroller>
                </div>
                <div class="filter_bd" :style="{ height: is_ios ? (table_height || 2*page_height) : 'auto'}">
                    <scroller class="filter_scroller" scroll-direction="horizontal">
                        <div class="table_box">
                            <div class="list" ref="table_box">
                                <div class="cell_box">
                                    <div class="item tb_hd">
                                        <div class="tb_td coin_info">
                                            <text class="tb_th">币种</text>
                                        </div>
                                        <div class="tb_td market_cap">
                                            <text class="tb_th">市值(CNY)</text>
                                        </div>
                                        <div class="tb_td coin_price">
                                            <text class="tb_th">价格/当日涨跌</text>
                                        </div>
                                        <div :class="['tb_td', 'coin_num', `${item.key}`]" v-for="item in route_query" v-if="item.name">
                                            <text class="tb_th">{{item.name}}</text>
                                        </div>
                                    </div>
                                </div>
                                <div class="cell_box" v-for="(coin, idnex) in coin_list">
                                    <div class="item" @click="jumpCoinsDetail(coin)">
                                        <div class="tb_td coin_info">
                                            <CoinItemInfo :coin="coin"></CoinItemInfo>
                                        </div>
                                        <div class="tb_td market_cap">
                                            <text class="text">{{String(coin.market_cap_cny_str || '').replace('¥', '')}}</text>
                                        </div>
                                        <div class="tb_td coin_price">
                                            <text :class="['text', coin.percent_change_8am > 0 ? 'safe' : 'warn']">{{coin.price_cny_str}}</text>
                                            <text :class="['text', 'coin_percent', coin.percent_change_8am > 0 ? 'safe' : 'warn']">{{coin.percent_change_8am_str}}</text>
                                        </div>
                                        <div :class="['tb_td', 'coin_num', `${order.key}`]" v-for="order in route_query" v-if="order.name">
                                            <text class="text">{{coin[order.key]}}</text>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </scroller>
                    <div>
                        <Loadmore :loading="loading.coin_list"></Loadmore>
                    </div>
                </div>
            </scroller>
        </div>
    </div>
</template>
<script>

import { Utils, WxcButton } from 'weex-ui';
import WxcMinibar from '../components/WxcMinibar.vue'
import StatusBar from '../components/StatusBar.vue'
import Refresher from '../components/Refresher.vue'
import Loadmore from '../components/Loadmore.vue'
import CoinItemInfo from '../components/CoinItemInfo.vue'
import { API_BaseUrl, Iconfont } from '../config/config.js'
import filters from '../config/filters.js'
const dom = weex.requireModule('dom')
export default {
    components: {
        WxcButton,
        WxcMinibar,
        StatusBar,
        Refresher,
        Loadmore,
        CoinItemInfo
    },
    data() {
        return {
            filters,
            router_params: {},
            loading: {
                coin_list: 'loading',
            },
            page: {
                coin_list: 1,
            },
            size: {
                coin_list: 30,
            },
            coin_list: [],
            statusBarStyle: {
                bgColor: '#ffffff',
            },
            route_query: [],
            table_height: 0,
            is_ios: weex.config.env.platform === 'iOS' ? true : false,
        };
    },
    beforeCreate() {
        var domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont2",
            'src': `url('${Iconfont}')`
        });
    },
    created() {
        
        this.init();
    },
    methods: {
        init() {
            this.getRouterParams();
        },
        initRouteQuery(route) {
            for (let key in route) {
                this.route_query.push({
                    key: key,
                    value: route[key],
                    name: this.filters.getOrderName(key, route[key])
                })
            };
        },
        getRouterParams() {
            this.$router.getParams().then(resData => {
                this.router_params = resData;
                this.initRouteQuery(resData);
                this.getCoins();
            })
        },
        
        jumpCoinsDetail(coin) {
            this.$router.open({
                name: 'CoinDetail',
                type: 'PUSH',
                params: {
                    symbol: coin.symbol,
                    symbol_id: coin.id,
                }
            })
        },
        scrollHandler(e) {
            if (!this.is_ios) {
                return;
            }
            dom.getComponentRect(this.$refs.table_box, option => {
                this.table_height = option.size.height + 100;
            })
        },
        refresh() {
            this.page.coin_list = 1;
            this.getCoins();
        },
        loadmoreCoin() {
            if (this.loading.coin_list !== 'loaded') {
                return;
            }
            this.page.coin_list++;
            this.getCoins();
        },
        getCoins() {
            let params = {};
            for (let key in this.router_params) {
                params[key] = this.router_params[key];
            };
            params.items = true;
            params.page = this.page.coin_list;
            params.size = this.size.coin_list;
            this.loading.coin_list = 'loading';
            this.$fetch({
                name: 'getCoins',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.coin_list = 'loaded';
                    for(let item of resData.items) {
                        if (params.price_max === '价格创近7天新高') {
                            item.price_max = `￥${this.filters.fixNumber(item.max_7day)}`;
                        }
                        if (params.price_max === '价格创近30天新高') {
                            item.price_max = `￥${this.filters.fixNumber(item.max_30day)}`;
                        }
                        if (item.conceptual_plate && item.conceptual_plate.length) {
                            item.conceptual_plate = item.conceptual_plate.join(',');
                        }
                        item.is_star_team = this.filters.getTrueAndFalse(item.is_star_team);
                        item.fall_back = this.filters.getTrueAndFalse(item.fall_back);
                        item.attack = this.filters.getTrueAndFalse(item.attack);
                        item.average_price_precent_rank = `￥${this.filters.fixNumber(item.price_cny)}/￥${this.filters.fixNumber(item.average_price)}`;
                        item.percent_change_24h_rank = item.percent_change_24h_str;
                        item.polocy_profitable = this.filters.getPosAndNeg(item.polocy_profitable);
                        
                    }
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.coin_list = 'nomore';
                        }
                        this.coin_list.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.coin_list = 'empty';
                        }
                        this.coin_list = resData.items;
                    }
                } else {
                    this.loading.coin_list = 'error';
                    this.$notice.toast({ message: resData.message })
                }

            }).catch((e) => {
                this.loading.coin_list = 'error';
                console.log(e.message)
            });
        },
    },
    computed: {
        page_height() {
            return Utils.env.getPageHeight();
        },
    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.container {}

.wrapper {
    flex-direction: column;
}

.box_bd {
    height: 800px;
}

.box_ft {}

.icon {
    font-family: iconfont2;
}

.filter_hd {
    flex-direction: row;
    align-items: center;
}

.filter_scroller {
    flex-direction: row;
    flex: 1;
}

.filter_title {
    padding-left: @padding_size;
    color: #333;
    margin-right: 20px;
    font-size: 24px;
}

.option {
    font-size: 22px;
    background-color: #C2C8D0;
    padding: 10px 15px;
    margin-right: 20px;
    border-radius: 3px;
    margin-bottom: 10px;
    color: #fff;
}

.box_hd {
    flex-direction: row;
    align-items: center;
    padding-top: 25px;
    padding-bottom: 25px;
    font-size: 22px;
}
.filter_bd {
    
}
.left {
}
.list {
    
}

.cell_box {
    background-color: #fff;
}

.item {
    padding: @padding_size;
    border-bottom-width: 1px;
    border-color: #eee;
    flex-direction: row;
    align-items: center;
}

.tb_hd {
    padding-left: @padding_size;
    padding-right: @padding_size;
    padding-top: 15px;
    padding-bottom: 15px;
    background-color: @bgf4f5f6;
}

.tb_td {

}

.coin_rank {
    width: 90px;
}

.market_cap {
    width: 240px;
}

.coin_info {
    width: 240px;
}

.coin_price {
    width: 220px;
}

.text {
    font-size: 28px;
}

.warn {
    color: @warn_color;
}

.safe {
    color: @safe_color;
}

.tb_th {
    font-size: 24px;
    color: #9B9DA4;
}
.coin_box {
    flex-direction: row;
    align-items: center;
}
.coin_logo {
    width: 35px;
    height: 35px;
    border-radius: 50%;
}
.coin_text {
    padding-left: 15px;
}
.logo_image {
    width: 35px;
    height: 35px;
}
.coin_name {
    font-size: 22px;
    color: #9B9DA4;
    text-overflow: ellipsis;
    line: 1;
}

.coin_percent {
    font-size: 20px;
}
.coin_num {
    width: 200px;
}
</style>
