<template>
    <div class="container">
        <StatusBar :statusBarStyle="statusBarStyle"></StatusBar>
        <wxc-minibar :title="`${symbol}-${coin.cn || coin.name || ''}(均价)`">
            <!-- <text slot="right" class="icon right_icon" @click="minibarRightButtonClick">&#xe90b;</text> -->
        </wxc-minibar>
        <list class="wrapper_list" ref="coindetail_dom" loadmoreoffset="30" @loadmore="loadmorePlatforms" :style="{height: tabPageHeight}">
            <Refresher @refresh="refreshCoins" @refreshEnd="refreshEnd"></Refresher>
            <cell>
                <div class="box_hd">
                    <div class="list">
                        <div class="item item_price">
                            <text :class="['top', 'top_special', 'price_cny', selected.percent_change_8am > 0 ? 'safe' : 'warn']">{{selected.price_cny_str}}</text>
                            <text :class="['bottom', 'bottom_special', 'price_usd', selected.percent_change_8am > 0 ? 'safe' : 'warn']">{{selected.price_usd_str}}</text>
                        </div>
                        <div class="item">
                            <text class="top">24h最高</text>
                            <text class="bottom">{{selected.price_cny_high_24h_str || '--'}}</text>
                        </div>
                        <div class="item">
                            <text class="top">24h最低</text>
                            <text class="bottom">{{selected.price_cny_low_24h_str || '--'}}</text>
                        </div>
                        <div class="item">
                            <text class="top">24h成交量</text>
                            <text class="bottom">{{selected.volume_24h_str}}</text>
                        </div>
                    </div>
                    <div class="list list_bottom">
                        <div class="item item_price">
                            <text class="top top_special"></text>
                            <text :class="['bottom', 'bottom_special', 'percent_change', selected.percent_change_8am > 0 ? 'safe' : 'warn']">{{selected.percent_change_8am_str}}</text>
                        </div>
                        <div class="item">
                            <text class="top">市值</text>
                            <text class="bottom">{{coin.market_cap_usd_str}}</text>
                        </div>
                        <div class="item">
                            <text class="top">排名</text>
                            <text class="bottom">#{{coin.rank}}</text>
                        </div>
                        <div class="item">
                            <text class="top">流通量（{{coin.symbol}}）</text>
                            <text class="bottom">{{coin.available_supply_str}}</text>
                        </div>
                    </div>
                </div>
            </cell>
            <cell>
                <div class="box_bd">
                    <CoinPriceLine></CoinPriceLine>
                </div>
            </cell>
            <cell>
                <div class="box_ft">
                    <div>
                        <bui-tabbar :tabItems="tabTitles" showSelectedLine=true @change="onItemChange" v-model="currentTabIndex" :height="tabStyles.height" :background="tabStyles.background" :selectedBackground="tabStyles.selectedBackground" :titleSize="tabStyles.titleSize"></bui-tabbar>
                    </div>
                    <slider class="slider" :scrollable="!is_ios" @change="onSliderChange" :index="currentTabIndex" infinite="false">
                        <div class="slider-item">
                            <CoinPlatforms v-if="currentTabIndex === 0" :is_loadmore="is_loadmore" :is_refresh="is_refresh" @Loadmoreing="Loadmoreing"></CoinPlatforms>
                        </div>
                        <div class="slider-item">
                            <CoinArticle v-if="currentTabIndex === 1" :is_loadmore="is_loadmore" :is_refresh="is_refresh" @Loadmoreing="Loadmoreing"></CoinArticle>
                        </div>
                        <div class="slider-item">
                            <CoinDiagnose v-if="currentTabIndex === 2" :is_loadmore="is_loadmore" :is_refresh="is_refresh" @Loadmoreing="Loadmoreing"></CoinDiagnose>
                        </div>
                        <div class="slider-item">
                            <CoinInfo v-if="currentTabIndex === 3" :is_loadmore="is_loadmore" :is_refresh="is_refresh" @Loadmoreing="Loadmoreing"></CoinInfo>
                        </div>
                        <div class="slider-item">
                            <CoinAnalyse v-if="currentTabIndex === 4" :is_loadmore="is_loadmore" :is_refresh="is_refresh" @Loadmoreing="Loadmoreing"></CoinAnalyse>
                        </div>
                    </slider>
                </div>
            </cell>
            <cell style="height: 150px;"></cell>
        </list>
        <div class="btn_box">
            <div class="btn_item" @click="addUserCoin">
                <text class="icon icon_btn" v-if="selected.is_star">&#xe90a;</text>
                <text class="icon icon_btn" v-if="!selected.is_star">&#xe93a;</text>
                <text class="symbol_text">自选</text>
            </div>
            <div class="btn_item" @click="jumpCoinStat" v-if="!hideModule['Stare']">
                <text class="icon icon_btn">&#xe93c;</text>
                <text class="symbol_text">盯盘</text>
            </div>
        </div>
        <DialogTaskDone v-if="show_dialog_task_done" task="done_daily_coin" @closeDialog="closeDialog"></DialogTaskDone>
    </div>
</template>
<script>
import { Utils, WxcButton } from 'weex-ui';
import WxcMinibar from '../components/WxcMinibar.vue'
import StatusBar from '../components/StatusBar.vue'
import Loadmore from '../components/Loadmore.vue'
import Refresher from '../components/Refresher.vue'
import CoinItem from '../components/CoinItem.vue'
import CoinInfo from '../components/CoinInfo.vue'
import CoinArticle from '../components/CoinArticle.vue'
import CoinAnalyse from '../components/CoinAnalyse.vue'
import CoinPriceLine from '../components/CoinPriceLine.vue'
import CoinPlatforms from '../components/CoinPlatforms.vue'
import CoinDiagnose from '../components/CoinDiagnose.vue'
import { API_BaseUrl, Iconfont } from '../config/config.js'
import BuiTabbar from '../components/BuiTabbar.vue'
import DialogTaskDone from '../components/DialogTaskDone.vue'
import utils from '../config/utils'
import common from '../config/common';
const screenShot = weex.requireModule('screenShot')

export default {
    components: {
        WxcMinibar,
        WxcButton,
        StatusBar,
        BuiTabbar,
        Loadmore,
        Refresher,
        CoinItem,
        CoinInfo,
        CoinAnalyse,
        CoinDiagnose,
        CoinArticle,
        CoinPriceLine,
        CoinPlatforms,
        DialogTaskDone
    },
    data() {
        return {
            hideModule: this.$storage.getSync('hideModule') || {},
            is_ios: weex.config.env.platform === 'iOS' ? true : false,
            show_dialog_task_done: false,
            title: '',
            router_params: {},
            statusBarStyle: {
                bgColor: '#ffffff',
            },
            currentTabIndex: 0,
            tabStyles: {
                height: 90,
                background: '#ffffff',
                selectedBackground: '#ffffff',
                titleSize: 34,
                normalColor: '#434343',
                selectedColor: '#F7B237',
                borderBottomColor: '#F7B237',
            },
            is_loadmore: false,
            is_refresh: false,
            tabTitles: [{
                    title: '行情',
                    type: 'bargain',
                    active: true
                },
                {
                    title: '资讯',
                    type: 'info',
                    active: false
                },
                {
                    title: '诊币',
                    type: 'info',
                    active: false
                },
                {
                    title: '概述',
                    type: 'info',
                    active: false
                },
                {
                    title: '分析',
                    type: 'info',
                    active: false
                },

            ],
            currentTitle: '',
            default_price: '',
            coin: {
                name: ''
            },
            symbol: '',
            selected: {
                pair_symbol: '',
                pair_base: '',
                platform: '',
            },
            loading: {
                coin_ks: 'loading',
            },
        };
    },
    beforeCreate() {
        var domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont2",
            'src': `url('${Iconfont}')`
        });
    },
    created() {
        this.init();
    },
    eros: {
        beforeBackAppear(params, options) {
            this.getCoin();
        },
        // app 前后台相关 start 
        appActive() {
            // 前台
        },
        appDeactive() {
            // 后台
        },
        // app 前后台相关 end 
        beforeDisappear (options) {
            // 离开页面
        }
    },
    methods: {
        init() {
            this.getRouterParams();
        },
        addUserCoin() {
            if (this.selected.is_star) {
                this.deleteUserCoin();
            } else {
                this.postUserCoin();
            }
        },
        closeDialog() {
            this.show_dialog_task_done = false;
        },
        getRouterParams() {
            this.$router.getParams().then(resData => {
                this.router_params = resData;
                this.currentTabIndex = this.router_params.tabIndex || 0;
                this.currentTab = this.tabTitles[this.currentTabIndex];
                this.symbol = resData.pair_symbol || resData.symbol;
                this.selected.pair_symbol = this.symbol;
                this.selected.pair_base = resData.pair_base || '';
                this.selected.platform = resData.platform || '均价';
                this.getCoin();
                this.postUserTokenDailyReadCoin();
            })
        },
        refreshCoins() {
            this.is_refresh = true;
            this.getCoin();
        },
        refreshEnd() {
            this.is_refresh = false;
        },
        postUserTokenDailyReadCoin() {
            let params = {};
            params.symbol_id = this.router_params.symbol_id;
            params.quote = this.selected.pair_symbol;
            params.base = this.selected.pair_base;
            params.platform = this.selected.platform;
            console.log(params);
            this.$fetch({
                name: 'postUserTokenDailyReadCoin',
                method: 'POST',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.show_dialog_task_done = true; // 组件里面会检查任务是否完成，完成就显示弹框
                } else {
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((e) => {
                console.log(e.message)
            });
        },
        onItemChange(index) {
            this.currentTab = this.tabTitles[index];
            this.currentTabIndex = index;
        },
        onSliderChange(e) {
            var index = e.index;
            this.currentTab = this.tabTitles[e.index];
            this.currentTabIndex = index;
        },
        minibarRightButtonClick() {
            this.$notice.toast({ message: 'ssssss' });
            screenShot.shotOfDecoView((result) => {
                console.log('deco-img', result);
            })

        },
        getCoin() {
            let params = {};
            params.symbol = this.symbol;
            params.symbol_id = this.router_params.symbol_id;
            this.$fetch({
                url: `${API_BaseUrl}/api/coin/${params.symbol}`,
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.coin = resData.result;
                    resData.result.is_star ? resData.result.is_star = true : resData.result.is_star = false;
                    if (this.selected.platform === '均价') {
                        this.selected = resData.result;
                    }
                } else {
                    this.$notice.toast({ message: resData.message });
                }
            }).catch((e) => {
                console.log(e.message);
            });
        },
        postUserCoin() {
            let params = {
                platform: this.selected.platform,
                pair_symbol: this.selected.pair_symbol,
                pair_base: this.selected.pair_base,
                symbol_id: this.router_params.symbol_id,
            };
            if (this.selected.platform === '均价') {
                params.pair_symbol = this.selected.symbol || this.symbol;
                params.pair_base = '';
            }
            this.$notice.loading.show();
            this.$fetch({
                name: 'postUserCoin',
                method: 'POST',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.$notice.toast({ message: '已添加' })
                    this.selected.is_star = true;
                    // 友盟统计-自定义事件计数
                    common.addUmengClickEvent('bzh_cointrade_add_click');
                } else {
                    this.$notice.toast({ message: resData.message });
                }
                this.$notice.loading.hide()

            }).catch((e) => {
                console.log(e.message);
                this.$notice.loading.hide();
            });
        },
        deleteUserCoin() {
            let params = {
                platform: this.selected.platform,
                pair_symbol: this.selected.pair_symbol,
                pair_base: this.selected.pair_base,
                symbol_id: this.router_params.symbol_id,
            };
            if (this.selected.platform === '均价') {
                params.pair_symbol = this.selected.symbol || this.symbol;
                params.pair_base = '';
            }
            let query_str = utils.getQueryStr(params);
            this.$notice.loading.show();
            this.$fetch({
                url: `${API_BaseUrl}/api/user/coin?${encodeURI(query_str)}`,
                method: 'DELETE',
                data: {}
            }).then(resData => {
                if (resData.error === 0) {
                    this.$notice.toast({ message: '已取消' })
                    this.selected.is_star = false;
                } else {
                    this.$notice.toast({ message: resData.message });
                }
                this.$notice.loading.hide()

            }).catch((e) => {
                console.log(e.message);
                this.$notice.loading.hide();
            });
        },
        loadmorePlatforms() {
            this.is_loadmore = true;
        },
        Loadmoreing() {
            this.is_loadmore = false;
            this.$refs.coindetail_dom.resetLoadmore(); // 滚动到列表末尾时将强制触发loadmore
        },
        jumpCoinStat() {
            let { pair_base, pair_symbol, platform, symbol } = this.selected;
            let symbol_id = this.router_params.symbol_id;
            if (platform === '均价') {
                this.$router.open({
                    name: 'Stare',
                    params: {
                        symbol,
                        platform,
                        symbol_id,
                    }
                });
            } else {
                this.$router.open({
                    name: 'Stare',
                    params: {
                        pair_base,
                        pair_symbol,
                        platform,
                        symbol_id,
                    }
                });
            }
        },
    },
    computed: {
        tabPageHeight() {
            return Utils.env.getPageHeight();
        }
    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.container {}

.icon {
    font-family: iconfont2;
}

.right_icon {
    font-size: 40px;
}

.box_hd {
    padding-left: @padding_size;
    padding-right: @padding_size;
    padding-top: 15px;
    padding-bottom: 15px;
    background-color: #fff;
    border-color: #eee;
    border-bottom-width: 1px;
}

.list {
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
}

.list_bottom {
    margin-top: 5px;
}

.item {
    flex: 1;
    flex-direction: column;
}

.item_price {
    flex: 1.3;
}

.top {
    color: #9b9da4;
    font-size: 20px;
}

.bottom {
    color: #434343;
    font-size: 22px;
    margin-top: 6px;
    font-weight: bold;
}

.top_special {
    font-size: 34px;
    font-weight: bold;
}

.bottom_special {
    font-size: 22px;
}

.percent_change {
    position: relative;
    top: 5px;
}

.price_cny {
    text-align: left;
}

.price_usd {
    text-align: left;
}

.box_bd {
    background-color: #EFF3F4;
    margin-bottom: 15px;
}

.box_ft {
    width: 750px;
    min-height: 900px;
}

.slider-item {
    width: 750px;
}

.slider {
    width: 750px;
}

.tabs {
    flex-direction: row;
    justify-content: space-between;
    border-width: 1px;
    border-color: rgba(0, 0, 0, .1);
    background-color: #fff;
}

.button {
    flex: 1;
    font-size: 30px;
    text-align: center;
    padding: 25px 0;
}

.active {
    color: #f7b237;
    border-bottom-width: 2px;
    border-bottom-color: #f7b237;
    border-bottom-style: solid;
}

.warn {
    color: @warn_color;
}

.safe {
    color: @safe_color;
}

.safe_bg {
    background-color: @safe_color;
}

.warn_bg {
    background-color: @warn_color;
}


.k_wrap_list {}

.k_wrap_item {
    padding: @padding_size;
    flex-direction: row;
    align-items: center;
}

.k_wrap_item_1n {
    background-color: #F4F6F9;
}

.k_wrap_item_2n {
    background-color: #ffffff;
}

.k_wrap_tips {
    padding-left: @padding_size;
    padding-right: @padding_size;
    padding-top: 10px;
    font-size: 23px;
    color: #999;
    background-color: #EFF3F4;
}

.k_wrap_name {
    flex-direction: row;
    color: #434343;
    flex: 1;
    text-align: left;
}

.k_wrap_value {
    font-size: 28px;
    color: #777;
    flex: 3;
    text-align: right;
}

.k_wrap_image_icon {
    position: relative;
    color: #666;
    font-size: 35px;
}

.k_wrap_text {
    font-size: 28px;
    padding-left: 25px;
    color: #666;
}

.btn_box {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    width: 750px;
    height: 98px;
    flex-direction: row;
    border-top-width: 2px;
    border-color: #eee;
    align-items: center;
    justify-content: center;
    background-color: #fff;
}
.btn_item {
    flex: 1;
    height: 78px;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    border-right-width: 1px;
    border-color: #eee;
}

.symbol_text {
    padding-left: 10px;
    color: #434343;
}
.icon_btn {
    font-size: 40px;
    color: #434343;
}

</style>
