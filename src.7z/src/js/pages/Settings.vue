<template>
    <div class="container">
        <div class="wrapper">
            <wxc-minibar title="我的" :useDefaultReturn="false">
                <div slot="left" @wxcMinibarLeftButtonClicked="wxcMinibarLeftButtonClicked"></div>
            </wxc-minibar>
            <list :style="{height: page_height}">
                <Refresher @refresh="refresh"></Refresher>
                <cell>
                    <div class="box_hd">
                        <div class="head" @click="goUpdateSetting">
                            <div class="user_image">
                                <image class="user_image" resize="color" :src="user_info.headimgurl || default_header">
                            </div>
                            <text class="name">{{user_info.nickname || user_info.phone}}</text>
                            <div class="edit_box" v-if="user_info.is_login">
                                <text class="icon">&#xe91e;</text>
                            </div>
                        </div>
                        <div class="body">
                            <div class="login_box" v-if="!user_info.is_login">
                                <text class="login" @click="goLogin">登录 / </text>
                                <text class="register" @click="goRegister">注册</text>
                            </div>
                            <div class="login_box" v-if="user_info.is_login">
                                <text class="icon" @click="LoginOut">退出</text>
                            </div>
                        </div>
                    </div>
                </cell>
                <cell>
                    <div class="box_bd" v-if="!hideModule['TaskCenter']">
                        <CellItem :has-arrow="true" @wxcCellClicked="jumpTaskCenter" :has-top-border="false" :has-bottom-border="false" title="任务中心" hasVerticalIndent="" :titleImage="taskcenter" titleIconSize="36" extraContent="更多">
                            <div class="invite_title" slot="title_text">
                                <text class="invite_name">任务中心</text>
                                <text class="invite_tag">+BZH</text>
                            </div>
                        </CellItem>
                        <div class="list_box">
                            <TaskItem :task="task" v-for="(task, i) in task_list" :key="i" @taskClick="taskClick"></TaskItem>
                        </div>
                    </div>
                </cell>
                <cell>
                    <div class="box_ft">
                        <CellItem :has-arrow="true" @wxcCellClicked="goWallet" :has-top-border="false" title="我的钱包" hasVerticalIndent="" :titleImage="settings_wallet" titleIconSize="36" :extraContent="`${bzh} BZH`">
                        </CellItem>
                        <CellItem :has-arrow="true" @wxcCellClicked="goBetList" :has-top-border="false" title="我的竞猜" hasVerticalIndent="" :titleImage="settings_my_bet" titleIconSize="36" extraContent="" v-if="!hideModule['BetMy']">
                            <div class="invite_title mine_bet_title" slot="title_text">
                                <text class="invite_name">我的竞猜</text>
                                <image class="new_image" src="bmlocal://assets/images/bets/new.png" />
                            </div>
                            <div slot="value" v-if="unview_num > 0">
                                <text class="dot_text"></text>
                            </div>
                        </CellItem>
                        <CellItem :has-arrow="true" @wxcCellClicked="goAirdropList" :has-top-border="false" title="空投广场" hasVerticalIndent="" :titleImage="settings_airdrop" titleIconSize="36" extraContent="">
                            <div class="invite_title mine_bet_title" slot="title_text">
                                <text class="invite_name">空投广场</text>
                                <image class="new_image" src="bmlocal://assets/images/bets/new.png" />
                            </div>
                            <div slot="value" v-if="unview_Airdrop > 0">
                                <text class="dot_text"></text>
                            </div>
                        </CellItem>
                    </div>
                    <div class="box_ft">
                        <!-- <CellItem :has-arrow="true" @wxcCellClicked="goChange" :has-top-border="false" title="异动" hasVerticalIndent="" :titleImage="settings_ask" titleIconSize="36" extraContent="">
                        </CellItem>
                        <CellItem :has-arrow="true" @wxcCellClicked="goMarket" :has-top-border="false" title="大盘" hasVerticalIndent="" :titleImage="settings_ask" titleIconSize="36" extraContent="">
                        </CellItem> -->
                        <CellItem :has-arrow="true" @wxcCellClicked="goNotice" :has-top-border="false" title="通知设置" hasVerticalIndent="" :titleImage="settings_ask" titleIconSize="36" extraContent="">
                        </CellItem>
                        <CellItem :has-arrow="true" @wxcCellClicked="goPlan" :has-top-border="false" title="监控套餐" hasVerticalIndent="" :titleImage="settings_buy" titleIconSize="36" :extraContent="user_plan.title" v-if="!hideModule['Stare']">
                        </CellItem>
                        <CellItem :has-arrow="true" @wxcCellClicked="jumpInvite" :has-top-border="false" title="邀请好友" hasVerticalIndent="" :titleImage="invite_share" titleIconSize="36" extraContent="">
                            <div class="invite_title" slot="title_text">
                                <text class="invite_name">邀请好友</text>
                                <text class="invite_tag">+BZH</text>
                            </div>
                        </CellItem>
                        <CellItem :has-arrow="true" @wxcCellClicked="goFeedback" :has-top-border="false" title="反馈建议" hasVerticalIndent="" :titleImage="feedback_image" titleIconSize="36" extraContent="">
                            <div class="invite_title" slot="title_text">
                                <text class="invite_name">反馈建议</text>
                            </div>
                        </CellItem>
                        <CellItem v-if="platform_android" :has-arrow="true" @wxcCellClicked="getToolsAppVersion" :has-top-border="false" title="版本更新" hasVerticalIndent="" :titleImage="settings_update" titleIconSize="36" :extraContent="app_version+version_text">
                        </CellItem>
                        <!-- <CellItem v-if="platform_android" :has-arrow="true" @wxcCellClicked="gomarket" :has-top-border="false" title="版本更新" hasVerticalIndent="" :titleImage="settings_update" titleIconSize="36" :extraContent="app_version+version_text">
                        </CellItem> -->
                        <div class="app_version" v-if="!platform_android">
                            <text class="app_version_text">当前版本{{app_version}}{{version_text}}</text>
                        </div>
                        <div class="app_version">
                            <text class="app_version_text">{{$t('请先选择门店')}}</text>
                        </div>
                    </div>
                </cell>
                <cell style="height: 220px;"></cell>
            </list>
        </div>
        <DialogTask :top="current_task.top || 350" :title="current_task.name" align="left" :single="true" :show="is_show_dialog" :iconImage="current_task.icon_image" :introContentImage="current_task.intro_content_image" :content="current_task.intro_content" :confirmText="current_task.confirmText" @wxcDialogCancelBtnClicked="closeDialog" @wxcDialogConfirmBtnClicked="confirm">
        </DialogTask>
        <DialogRedPacket v-if="show_packet" @closePacket="closePacket"></DialogRedPacket>
        <DialogSoftUpdate :show="dialog_update_show" :update_info="update_info" @closeDialog="DialogCancelUpdate" @ConfirmBtnClicked="DialogConfirmUpdate">
        </DialogSoftUpdate>
    </div>
</template>
<script>
import { Utils, WxcButton } from 'weex-ui';
import WxcMinibar from '../components/WxcMinibar.vue'
import CellItem from '../components/CellItem.vue'
import Refresher from '../components/Refresher.vue'
import Dialog from '../components/Dialog.vue'
import DialogTask from '../components/DialogTask.vue'
import TaskItem from '../components/TaskItem.vue'
import DialogRedPacket from '../components/DialogRedPacket.vue'
import { test, debug } from '../config/config.js'
import DialogSoftUpdate from '../components/DialogSoftUpdate.vue'
import common from '../config/common';

export default {
    components: {
        WxcButton,
        CellItem,
        WxcMinibar,
        Refresher,
        Dialog,
        DialogTask,
        TaskItem,
        DialogRedPacket,
        DialogSoftUpdate,
    },
    data() {
        return {
            hideModule: this.$storage.getSync('hideModule') || {},
            show_packet: false,
            taskcenter: `bmlocal://assets/images/settings/taskcenter.png`,
            settings_wallet: `bmlocal://assets/images/settings/wallet.png`,
            settings_ask: `bmlocal://assets/images/settings/ask.png`,
            settings_airdrop: `bmlocal://assets/images/settings/airdrop.png`,
            settings_my_bet: `bmlocal://assets/images/settings/my_bet.png`,
            settings_buy: `bmlocal://assets/images/settings/buy.png`,
            settings_update: `bmlocal://assets/images/settings/update.png`,
            invite_share: `bmlocal://assets/images/settings/invite_share.png`,
            feedback_image: `bmlocal://assets/images/feedback/feedback.png`,
            default_header: `bmlocal://assets/images/default_header.jpg`,
            loading: {
                logs: 'init',
            },
            bzh: 0,
            user_info: {},
            user_plan: {},
            update_info: {},
            dialog_update_show: false,
            is_ios: String(weex.config.env.platform).toLowerCase() === 'ios' ? true : false,
            test,
            version_text: test ? '-测试版' : (debug ? '-开发版' : ''),
            task_list: [{
                name: '阅读',
                type: 'done_daily_read',
                icon_image: `bmlocal://assets/images/tasks/read.png`,
                intro: '阅读5篇文章',
                btn_text: '+20 BZH',
                active: false,
                btn_active_text: '今天已经领取',
                intro_content: '阅读币智慧5篇以上文章（需有效浏览），可领取20BZH奖励，每天都可领取哦！',
                intro_content_image: '',
                confirmText: '马上去阅读',
                router_link: 'Index',
                router_link_params: {
                    tab: 3,
                    hide_poster: true
                },
            }, {
                name: '分享',
                type: 'done_daily_share',
                icon_image: `bmlocal://assets/images/tasks/share.png`,
                intro: '分享文章被5人阅读',
                btn_text: '+50 BZH',
                active: false,
                btn_active_text: '今天已经领取',
                intro_content: '分享的文章被5人阅读，可以获得50BZH。',
                intro_content_image: `bmlocal://assets/images/tasks/share_guide.jpg`,
                confirmText: '我知道了',
                top: 200,
            }, {
                name: '投票',
                type: 'done_daily_vote',
                icon_image: `bmlocal://assets/images/tasks/vote.png`,
                intro: '5次利好利空投票',
                btn_text: '+ 20 BZH',
                active: false,
                btn_active_text: '今天已经领取',
                intro_content: '每天参与文章投票5次，奖励20BZH',
                intro_content_image: `bmlocal://assets/images/tasks/vote_guide.jpg`,
                confirmText: '我知道了',
                top: 200,
            }],
            current_task: {},
            is_show_dialog: false,
            unview_num: 0,
            unview_Airdrop: 0,
            upload_desc: {
                version: '1.3.0',
                detail: [
                    "1:优化币详情", "2:fdfhsdfhs", "3:fdfhsdfhs"
                ]
            },
        };
    },
    props: {
        tabbarActive: {
            type: Boolean,
            default: false,
        },
    },
    beforeCreate: function() {

    },
    created() {
        console.log('sssssss', this.$t('组织'))
    },
    eros: {
        beforeBackAppear(params, options) {
            this.init();
        },
    },
    watch: {
        'tabbarActive': {
            handler(newValue) {
                if (newValue) {
                    this.init();
                }
            },
            deep: true,
        },
    },
    methods: {
        init() {
            this.getUserInfo();
            // getUserInfo 执行完后才获得 this.user_info，也就是登录了才获取下面的信息
            if (this.user_info.is_login) {
                this.getUserTokenTrans();
                this.getUserPlan();
                this.getUserTokenDailyStat();
                this.getUserBets();
                this.getAirdropList();
            }
        },
        wxcMinibarLeftButtonClicked() {
            return;
        },
        resetDataTaskList() {
            for (let item of this.task_list) {
                item.active = false;
            }
        },
        closeDialog() {
            this.is_show_dialog = false;
        },
        closePacket() {
            this.show_packet = false;
        },
        confirm() {
            this.is_show_dialog = false;
            if (!this.current_task.router_link) {
                return;
            }
            if (this.current_task.router_link === 'Index') {
                this.$emit('SetTabbarActive', this.current_task.router_link_params.tab);
            } else {
                this.$router.open({
                    name: this.current_task.router_link,
                    type: 'PUSH',
                    params: this.current_task.router_link_params || {}
                })
            }
        },
        jumpInvite() {
            this.$router.open({
                name: 'Invite',
                type: 'PUSH',
                params: {
                    from: 'settings'
                }
            })
        },
        gomarket() {
            this.$router.open({
                name: 'Market',
            })
        },
        jumpTaskCenter() {
            this.$router.open({
                name: 'TaskCenter',
                statusBarStyle: 'LightContent',
                type: 'PUSH',
                params: {}
            })
        },
        getToolsAppVersion() {
            let params = {};
            params.versioncode = weex.config.env.appVersion;
            params.platform = weex.config.env.platform;
            params.app_name = weex.config.env.appName;
            params.type = 'version';
            this.$fetch({
                name: 'getToolsAppVersion',
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.update_info = resData.result;
                    this.dialog_update_show = true;
                }
            }).catch((e) => {
                console.log(e.message)
            });
        },
        DialogCancelUpdate() {
            this.dialog_update_show = false;
        },
        DialogConfirmUpdate() {
            this.dialog_update_show = false;
        },
        getUserInfo() {
            this.user_info = this.$storage.getSync('user_info') || {};
        },
        goWallet() {
            this.$router.open({
                name: 'Wallet',
                statusBarStyle: 'LightContent',
            })
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent('bzh_purse_enter');
        },
        goRegister() {
            this.$router.open({
                name: 'ReceiveBzh',
                type: 'PUSH',
                params: {
                    name: 'register'
                },
                canBack: false,
                gesBack: false,
            })
        },
        goPlan() {
            this.$router.open({
                name: 'Plan',
            })
        },
        goNotice() {
            this.$router.open({
                name: 'Notice',
            })
        },
        goFeedback() {
            this.$router.open({
                name : 'Feedback',
            })
        },
        goMarket() {
            this.$router.open({
                name: 'Market',
            })
        },
        goChange() {
            this.$router.open({
                name: 'Change',
            })
        },
        goBetList() {
            this.$router.open({
                name: 'BetMy',
            });
            this.putUserBetView();
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent('bzh_gamble_mine');
        },
        goAirdropList() {
            this.$router.open({
                name: 'AirdropList',
            })
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent('bzh_airdrop_enter');
        },
        goLogin() {
            this.$router.open({
                name: 'Login',
                params: {}
            })
        },
         LoginOut() {
            const storageLanguage = this.$storage.getSync('language')
            const storageHideModule = this.$storage.getSync('hideModule')
            this.$storage.removeAll().then(res => {
                this.$storage.setSync('language', storageLanguage)
                this.$storage.setSync('hideModule', storageHideModule)
                this.resetData();
                this.init();
                console.log('本地所有持久化存储的数据都已被清空。')
            })
        },
        resetData() {
            this.bzh = 0;
            this.user_info = {};
            this.user_plan = {};
            this.update_info = {};
            this.resetDataTaskList();
        },
        refresh() {
            this.getUserInfo();

            // 这里不用判断是否登录，用户主动刷新的时候，如果没有登录就跳到登录页面
            if (this.user_info.is_login) {
                this.getUserTokenTrans();
                this.getUserPlan();
            }
        },
        getUserTokenTrans() {

            let params = {};
            this.$fetch({
                name: 'getUserTokenTrans',
                method: 'GET',
                data: params
            }).then(resData => {
                this.bzh = resData.result.total;
            }).catch((e) => {

            });
        },
        getUserPlan() {
            let params = {};
            this.$fetch({
                name: 'getUserPlan',
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.user_plan = resData.result;
                } else {
                    this.$notice.toast({ message: resData.message });
                }
            }).catch((e) => {
                console.log(e.message);
            });
        },
        goUpdateSetting() {
            if (!this.user_info.is_login) {
                return;
            }
            this.$router.open({
                name: 'UpdateSetting',
                params: {}
            })
        },
        getUserTokenDailyStat() {
            let params = {};
            this.$fetch({
                name: 'getUserTokenDailyStat',
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    for (let item of this.task_list) {
                        for (let k in resData.result) {
                            if (item.type === k && resData.result[k] === true) {
                                item.active = true;
                            }
                        }
                    };
                    // 可以领取红包，且没有领取过
                    if (resData.result.can_get_redpacket && !resData.result.done_daily_redpacket) {
                        this.show_packet = true;
                    }

                } else {
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((e) => {
                console.log(e.message);
            });
        },
        getUserBets() {
            let params = {};
            params.items = 0;
            this.$fetch({
                name: 'getUserBets',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.unview_num = resData.unview || 0;
                }
            }).catch((e) => {

            });
        },
        getAirdropList() {
            let params = {};
            params.page = 1;
            params.size = 1;
            params.items = 0;
            this.$fetch({
                name: 'getAirdropList',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.unview_Airdrop = resData.unview || 0;
                }
            }).catch((e) => {

            });
        },
        putUserBetView() {
            if (!this.user_info.is_login) {
                return;
            }
            let params = {};
            this.$fetch({
                name: 'putUserBetView',
                method: 'PUT',
                data: params
            }).then(resData => {
                if (resData.error === 0) {

                }
            }).catch((e) => {

            });
        },
        taskClick(task) {
            this.is_show_dialog = true;
            this.current_task = task;
        },
    },
    computed: {
        app_version() {
            return `v${weex.config.env.appVersion}`;
        },
        platform_android() {
            return String(weex.config.env.platform).toLowerCase() === 'android';
        },
        page_height() {
            return Utils.env.getPageHeight();
        },
    }
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.container {}

.icon {
    color: #434343;
    font-family: iconfont2;
    font-size: 30px;
}

.wrapper {}

.box_hd {
    height: 90px;
    font-size: 34px;
    justify-content: center;
    align-items: center;
    background-color: #fff;
}

.box_bd {
    margin-top: 22px;
}

.back {
    position: absolute;
    font-size: 67px;
    bottom: 10px;
}

.seting {
    font-weight: bold;
}

.box_hd {
    justify-content: space-between;
    flex-direction: row;
    align-items: center;
    height: 150px;
    background-color: #fff;
    margin-top: 20px;
}

.list_box {
    width: 750px;
    flex-direction: row;
    flex-wrap: wrap;
    border-bottom-width: 1px;
    border-color: #eee;
    background-color: #fff;
}

.head {
    flex-direction: row;
    align-items: center;
    margin-left: 30px;
}

.body {
    margin-right: 30px;
}

.login_box {
    flex-direction: row;
}

.edit_box {
    padding-left: 15px;
}

.login {
    color: #f7b237;
}

.register {
    color: #f7b237;
}

.user_image {
    width: 90px;
    height: 90px;
    border-radius: 50%;
}

.name {
    margin-left: 20px;
}

.box_ft {
    margin-top: 20px;
}

.icon {
    font-family: iconfont2;
}

.invite_title {
    position: relative;
    flex-direction: row;
    align-items: center;
    justify-content: center;
}

.mine_bet_title {
    height: 55px;
}

.dot_text {
    width: 15px;
    height: 15px;
    border-radius: 100%;
    background-color: #fd5b4e;
}

.invite_name {
    color: #333333;
    font-size: 30px;
}

.invite_tag {
    margin-left: 20px;
    padding: 3px 15px;
    border-width: 2px;
    border-color: @main_color;
    border-radius: 20px;
    font-size: 22px;
    color: @main_color;
}

.new_image {
    margin-left: 10px;
    position: relative;
    top: -15px;
    width: 60px;
    height: 26px;
}

.app_version_text {
    padding-top: 15px;
    text-align: center;
    font-size: 20px;
    color: #999;
}

</style>
