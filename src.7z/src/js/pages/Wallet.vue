<template>
    <div class="container">
        <div class="wrapper">
            <div class="head">
                <StatusBar :statusBarStyle="{bgColor:'transparent'}"></StatusBar>
                <wxc-minibar title="我的钱包" backgroundColor="transparent" text-color="#fff" borderBottomWidth="0px">
                    <wxc-icon slot="left" name="back" style="color: #fff;font-weight: bold;font-size: 60px;position: relative;left: -14px;" @wxcIconClicked="minibarLeftClicked"></wxc-icon>
                    <text slot="right" class="icon_list" @click="goWalletDetailList">明细</text>
                </wxc-minibar>
                <div class="bzh_box">
                    <div class="bzh_balance">
                        <text class="bzh_value">{{ bzh }}</text>
                        <text class="bzh_unit">BZH</text>
                    </div>
                    <div class="btn_pick" @click="jumpExtractBzh" v-if="!hideModule['ExtractBzh']">
                        <text class="btn_icon icon">&#xe934;</text>
                        <text class="btn_text">提币</text>
                    </div>
                </div>
            </div>
            <list ref="balance_dom" class="list" index="0" infinite="false" loadmoreoffset="550" :style="{ height: page_height }" @loadmore="loadmore">
                <Refresher @refresh="refreshWallet" @refreshEnd="refreshEnd" :loading="loading.airdrop"></Refresher>
                <cell class="body" v-if="!hideModule['ExtractBzh']">
                    <text class="tips_text">{{widthdraw.withdraw_tips}}</text>
                </cell>
                <cell class="foot" v-for="log in airdrop" v-if="!hideModule['Airdrop']">
                    <div class="item" @click="jumpAirdropDetail(log)">
                        <div class="less_star left">
                            <div class="air_logo">
                                <image class="air_logo" resize="cover" :src="log.icon || default_coin_icon"></image>
                            </div>
                            <div class="air_name">
                                <text class="text air_name_text">{{log.title}}</text>
                                <div class="less_row value_box">
                                    <text class="value_text">{{log.count}}</text>
                                    <text class="text value_text_unit">{{log.symbol}}</text>
                                </div>
                            </div>
                        </div>
                        <div class="right">
                            <div :class="['btn_box', log.button_state ? '' : 'btn_box_disable']" @click="jumpExtract(log)" v-if="!hideModule['ExtractBzh']">
                                <text :class="['btn_text', log.button_state ? '' : 'btn_text_disable']">{{log.button_text || '提币'}}</text>
                            </div>
                        </div>
                    </div>
                </cell>
                <cell>
                    <Loadmore :loading="loading.airdrop" empty="空空如也~" nomore="加载完了哦~"></Loadmore>
                </cell>
                <cell v-if="widthdraw.airdrop_tips && !hideModule['ExtractBzh']">
                    <div class="air_tips_box">
                        <text class="air_tips_text">{{widthdraw.airdrop_tips}}</text>
                    </div>
                </cell>
                <cell style="height: 300px;"></cell>
            </list>
            <Dialog title="" :content="widthdraw.withdraw_tips_alert" confirmText="我知道了" :show="dialog_show" :single="true" @wxcDialogConfirmBtnClicked="DialogConfirm">
            </Dialog>
        </div>
    </div>
    </div>
</template>
<script>
import { WxcTabBar, Utils, WxcButton, WxcIcon } from 'weex-ui';
import WxcMinibar from '../components/WxcMinibar.vue'
import StatusBar from '../components/StatusBar.vue'
import Loadmore from '../components/Loadmore.vue'
import filters from '../config/filters.js'
import Refresher from '../components/Refresher.vue'
import Dialog from '../components/Dialog.vue'
import { Iconfont } from '../config/config.js'

export default {
    components: {
        WxcTabBar,
        WxcButton,
        WxcIcon,
        StatusBar,
        WxcMinibar,
        Loadmore,
        Refresher,
        Dialog
    },
    data() {
        return {
            hideModule: this.$storage.getSync('hideModule') || {},
            loading: {
                airdrop: 'init',
            },
            airdrop_page: 1,
            airdrop_size: 30,
            airdrop: [],
            bzh: 0,
            filters,
            show_extract_bzh: false,
            dialog_show: false,
            default_coin_icon: `bmlocal://assets/images/default_coin_icon.png`,
            widthdraw: {},
        };
    },
    beforeCreate() {
        var domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont2",
            'src': `url('${Iconfont}')`
        });
    },
    created() {
        this.init();
    },
    eros: {
        beforeBackAppear(params, options) {
            this.init();
        },
    },
    methods: {
        init() {
            this.airdrop_page = 1;
            this.getUserTokenTrans();
            this.getAirdropWallets();
            this.getConfigTokenWithdraws();
        },
        loadmore() {
            this.getMoreLogs();
        },
        refreshWallet() {
            this.airdrop_page = 1;
            this.getAirdropWallets();
        },
        DialogConfirm() {
            this.dialog_show = false;
        },
        digitize(num) {
            return (num + "").split("").map(Number);
        },
        getMoreLogs() {
            if (this.loading.airdrop !== 'loaded') {
                return;
            }
            this.airdrop_page++;

            this.getAirdropWallets();
        },
        jumpExtractBzh() {
            if (!this.show_extract_bzh) {
                this.dialog_show = true;
                return;
            }
            this.$router.open({
                name: 'ExtractBzh',
                params: {},
            })
        },
        jumpExtract(log) {
            if (log.count <= 0) {
                this.$notice.toast({ message: '可提币数量不足~' });
                return;
            }
            if (!log.withdraw_enable) {
                this.$notice.toast({ message: log.withdraw_enable_cause });
                return;
            }
            this.$router.open({
                name: 'ExtractBzh',
                params: {
                    airdrop_id: log.airdrop_id
                },
            })
        },
        jumpAirdropDetail(log) {
            if (log.no_detail) {  //不能点击跳转
                
            }else{ // 可以点击进入详情
                this.$router.open({
                    name: 'AirdropDetail',
                    statusBarStyle: 'LightContent',
                    params: {
                        airdrop_id: log.airdrop_id
                    }
                })
            }
        },
        goWalletDetailList() {
            this.$router.open({
                name: 'WalletDetailList',
                params: {},
            })
        },
        minibarLeftClicked() {
            this.$router.back();
        },
        getAirdropWallets() {
            let params = {};
            params.page = this.airdrop_page;
            params.size = this.airdrop_size;
            this.loading.airdrop = 'loading';

            this.$fetch({
                name: 'getAirdropWallets',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.airdrop = 'loaded';
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.airdrop = 'nomore';
                        }
                        this.airdrop.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.airdrop = 'empty';
                        }
                        this.airdrop = resData.items;
                    }
                    this.$refs.balance_dom.resetLoadmore(); // 强制触发loadmore
                } else {
                    this.$notice.toast({ message: resData.message });
                    if (resData.error === 1) {
                        this.loading.airdrop = 'need_login';
                    } else {
                        this.loading.airdrop = 'error';
                    }
                }

            }).catch((e) => {
                console.log(e.message);
            });
        },
        getUserTokenTrans() {
            let params = {};
            this.$fetch({
                name: 'getUserTokenTrans',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.bzh = resData.result.total;
                } else {
                    this.$notice.toast({ message: resData.message });
                }
            }).catch((e) => {

            });
        },
        getConfigTokenWithdraws() {
            let params = {
                type: 'app_config',
                key: 'token_withdraw',
            };
            this.$fetch({
                name: 'getConfig',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.widthdraw = resData.result || {};
                    if (resData.result.withdraw_enable) {
                        let now_timestamp = Date.now() / 1000;
                        if (now_timestamp >= resData.result.start_timestamp) {
                            if (now_timestamp <= resData.result.end_timestamp) {
                                this.show_extract_bzh = true;
                            }
                        }
                    }
                }
            }).catch((e) => {
                console.log(e.message);
            });
        }
    },
    computed: {
        page_height() {
            return Utils.env.getPageHeight();
        },
    }
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.container {}

.icon {
    font-family: iconfont2;
}

.wrapper {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 750px;
}

.head {
    width: 750px;
    background-color: #f7bf4e;
    background-image: linear-gradient(to top left, #F4CD52, #F8BD4D);
}

.bzh_box {
    padding-top: 40px;
    width: 750px;
    flex-direction: row;
    align-items: center;
}

.bzh_balance {
    padding-left: @padding_size;
    flex: 1;
    flex-direction: row;
    align-items: center;
}

.bzh_value {
    font-size: 70px;
    font-weight: bold;
    color: #fff;
    padding: 30px 0;
    text-align: left;
}

.bzh_unit {
    padding-left: 30px;
    padding-top: 15px;
    color: #fff;
    font-size: 33px;
    font-weight: bold;
}

.btn_pick {
    margin-right: @padding_size;
    width: 165px;
    height: 70px;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    background-color: #fff;
    border-radius: 4px;
    box-shadow: 3px 4px 5px #F0B942;
}

.btn_icon {
    color: @main_color;
    font-size: 45px;
}

.icon_list {
    color: #fff;
    font-size: 34px;
}

.btn_text {
    padding-left: 10px;
    color: @main_color;
    font-size: 32px;
}

.btn_text_disable {
    color: #bbbdc3;
}

.body {
    padding: 10px @padding_size;
    justify-content: center;
    align-items: center;
    background-color: #FFF9EE;
}

.tips_text {
    font-size: 22px;
    color: #DDB46C;
    line-height: 37px;
    text-align: center;
}

.foot {
    padding: 0 30px;
}

.list {
    background-color: #fff;
}

.item {
    flex-direction: row;
    justify-content: space-between;
    border-bottom-style: solid;
    border-bottom-width: 1px;
    border-bottom-color: rgba(0, 0, 0, 0.1);
    padding: 30px 0;
    align-items: center;
}

.left {
    padding-right: 10px;
    align-items: center;
    flex: 3;
}

.right {
    align-items: center;
}

.btn_box {
    width: 140px;
    height: 60px;
    border-width: 2px;
    border-radius: 6px;
    border-color: @main_color;
    align-items: center;
    justify-content: center;
}

.btn_box_disable {
    border-color: #bbbdc3;
}

.value_box {
    align-items: center;
}

.air_logo {
    width: 90px;
    height: 90px;
    border-radius: 100%;
}

.air_name {
    flex: 1;
    padding-left: 20px;
}

.air_name_text {
    margin-bottom: 10px;
    font-size: 30px;
    lines: 1;


    text-overflow: ellipsis;
}

.value_text {
    color: @main_color;
    font-size: 28px;
    font-weight: bold;
}

.value_text_unit {
    padding-left: 10px;
    font-size: 28px;
}

.air_tips_box {
    margin: 44px 0;
}

.air_tips_text {
    text-align: center;
    font-size: 30px;
    color: @main_color;
}

</style>
