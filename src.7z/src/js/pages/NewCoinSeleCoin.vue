<template>
    <div class="container">
        <StatusBar></StatusBar>
        <wxc-minibar title="新币发行">
            <div class="bar_right" slot="right">
                <text class="icon bar_text" @click="openUrl">申请</text>
                <text class="icon" @click="goSearchCoin">&#xe915;</text>
            </div>
        </wxc-minibar>
        <div class="content">
            <div class="wrapper_scroller_box">
                <scroller class="wrapper_scroller" loadmoreoffset="600" @loadmore="loadmoreCoin" offset-accuracy="100" @scroll="scrollHandler" :style="{ height: page_height}" v-if="coin_list.length">
                    <!-- 左边 -->
                    <div :class="[!is_ios && 'fixed_box', is_ios && 'fixed_box_ios']" :style="{height: is_ios ? (table_height || page_height) : 'auto'}">
                        <div :class="[is_ios && 'fixed_box']" :style="{bottom: is_ios ? 0 : 'auto'}">
                            <div class="header">
                                <div class="header_list">
                                    <div :class="['header_item']">
                                        <div class="header_title">
                                            <text class="tb_th">币种</text>
                                            <text class="tb_th">/24h成交额(CNY)</text>
                                        </div>
                                    </div>
                                    <div :class="['header_item']">
                                        <div class="header_title">
                                            <text class="tb_th">价格(CNY)</text>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="list" ref="table_box">
                                <div class="cell_box" v-for="(coin, idnex) in coin_list" :key="idnex">
                                    <div class="item" @click="jumpCoinsDetail(coin)">
                                        <div class="tb_td coin_info">
                                            <div class="coin_name">
                                                <text class="text coin_cny">{{coin.symbol || coin.name}}</text>
                                                <text class="text coin_time">{{getTime(coin.publish_time)}}</text>
                                                <text class="text coin_tag" v-if="coin.recommend">推荐</text>
                                            </div>
                                            <text class="text coin_usd">{{String(coin.volume_cny_24h_str || '').replace('¥', '')}}</text>
                                        </div>
                                        <div class="tb_td market_cap">
                                            <text :class="['text', 'cny_price_text']">{{String(coin.price_cny_str || '').replace('¥', '')}}</text>
                                            <text :class="['text', 'us_price_text']">={{String(coin.price_usd_str || '').replace('$', '') }} USD</text>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 右边 -->
                    <div :class="[!is_ios && 'scroller_box', is_ios && 'scroller_box_ios']" :style="{height: is_ios ? (table_height || page_height) : 'auto'}">
                        <div :class="[is_ios && 'scroller_box']" :style="{bottom: is_ios ? 0 : 'auto',marginTop: is_ios ? -(table_height || page_height) : 'auto'}">
                            <scroller class="filter_scroller" scroll-direction="horizontal">
                                <div class="table_box">
                                    <div class="header">
                                        <div class="header_list">
                                            <div :class="['header_item']" v-for="(header, i) in table_head_list" :key="i">
                                                <div class="header_title">
                                                    <text class="title_text">{{header.name}}</text>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list" ref="table_box">
                                        <div class="cell_box" v-for="(coin, idnex) in coin_list" :key="idnex">
                                            <div class="item" @click="jumpCoinsDetail(coin)">
                                                <div class="tb_td coin_price" v-for="(table, i) in table_head_list" :key="i">
                                                    <text :class="['text', table.key === 'percent_change_8am' && 'coin_change' , getColorClass(coin, table.key)]">{{String(coin[table.key_str] || '--').replace('¥', '')}}</text>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </scroller>
                        </div>
                    </div>
                </scroller>
            </div>
            <Loadmore :loading="loading.coin_list"></Loadmore>
        </div>
    </div>
</template>
<script>
import { Utils } from 'weex-ui';
import Refresher from '../components/Refresher.vue'
import WxcMinibar from '../components/WxcMinibar.vue'
import StatusBar from '../components/StatusBar.vue'
import Loadmore from '../components/Loadmore.vue'
import CoinItemInfo from '../components/CoinItemInfo.vue'
import WxcPopover from '../components/WxcPopover.vue'
import WxcTabPage from '../components/WxcTabPage.vue'
import { Iconfont } from '../config/config.js'
const dom = weex.requireModule('dom')
export default {
    components: { WxcTabPage, Refresher, WxcMinibar, StatusBar, Loadmore, CoinItemInfo, WxcPopover },
    data() {
        return {
            is_ios: weex.config.env.platform === 'iOS' ? true : false,
            loading: {
                coin_list: 'loading',
            },
            coin_list: [],
            table_height: 0,
            table_head_list: [{
                name: '当日涨跌',
                class_name: 'coin_price',
                key: 'percent_change_8am',
                key_str: 'percent_change_8am_str',
            }, {
                name: '发行时间',
                class_name: 'coin_price',
                key: '',
                key_str: 'publish_time_str',
            }, {
                name: '现价/众筹价',
                class_name: 'coin_price',
                key: 'average_price_percent',
                key_str: 'average_price_percent_str',
            }, {
                name: '技术热度',
                class_name: 'coin_price',
                key: '',
                key_str: 'github_sum_count',
            }, {
                name: '媒体热度',
                class_name: 'coin_price',
                key: '',
                key_str: 'media_sum_count',
            }, {
                name: '上线交易所数量',
                class_name: 'coin_price',
                key: '',
                key_str: 'publish_count',
            }],
            coin_list_page: 1,
            coin_list_size: 20,
            router_params: {},
        }
    },
    beforeCreate() {
        var domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont2",
            'src': `url('${Iconfont}')`
        });
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.getCoinsByNew();
        },

        goSearchCoin() {
            this.$router.open({
                name: 'SearchCoin',
                params: {}
            })
        },
        jumpCoinsDetail(coin) {
            this.$router.open({
                name: 'CoinDetail',
                type: 'PUSH',
                params: {
                    symbol: coin.symbol,
                    symbol_id: coin.id,
                }
            })
        },
        scrollHandler(e) {
            if (!this.is_ios) {
                return;
            }
            dom.getComponentRect(this.$refs.table_box, option => {
                // this.table_height = option.size.height / 2 + 100;
            })
        },
        loadmoreCoin() {
            if (this.loading.coin_list !== 'loaded') {
                return;
            }
            this.coin_list_page++;
            this.getCoinsByNew();
        },
        getCoinsByNew() {
            let params = {};
            params.page = this.coin_list_page;
            params.size = this.coin_list_size;
            params.items = 1;
            this.loading.coin_list = 'loading';
            this.$fetch({
                name: 'getCoinsByNew',
                methods: 'GET',
                data: params,
            }).then((res) => {
                if (res.error === 0) {
                    this.loading.coin_list = 'loaded';
                    if (params.page === 1) {
                        this.coin_list = res.items;
                        if (!res.items.length) {
                            this.loading.coin_list = 'empty';
                        }
                    } else {
                        if (!res.items.length) {
                            this.loading.coin_list = 'nomore';
                        } else {
                            this.coin_list.push(...res.items);
                        }
                    }
                } else {
                    this.loading.coin_list = 'error';
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((err) => {
                console.error(err);
            });
        },
        getTime(ts) {
            if (ts) {
                return moment.unix(ts).startOf('hour').fromNow();
            } else {
                return '';
            }
        },
        openUrl() {
            this.$router.toWebView({
                url: 'http://cn.mikecrm.com/JaBK26n', // 页面 url
                title: '币智慧', // 页面 title
                navShow: true // 是否显示native端导航栏，默认是true
            })
        },
        getColorClass(coin, key) {
            if (key === 'percent_change_8am') {
                let name = '';
                name = coin[key] > 0 ? 'safe_bg' : 'warn_bg';
                return name;
            }
            if (key) {
                let name = '';
                name = coin[key] > 0 ? 'safe' : 'warn';
                return name;
            }
        },
    },
    computed: {
        page_height() {
            return Utils.env.getPageHeight();
        },
    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.icon {
    color: #434343;
    font-family: iconfont2;
    font-size: 45px;
}

.bar_right {
    flex-direction: row;
}

.bar_text {
    padding-top: 2px;
    font-size: 37px;
    padding-right: 30px;
}
.header_list {
    flex-direction: row;
}

.header_item {
    width: 240px;
    height: 90px;
    justify-content: center;
}

.header_title {
    padding-left: @padding_size;
}

.header_refs {
    justify-content: flex-end;
}

.title_text {
    font-size: 24px;
    color: #9B9DA4;
}

.icon_arrow {
    padding-left: 10px;
    font-size: 15px;
}

.icon_refs {
    padding-right: 10px;
    font-size: 24px;
}

.filter_scroller {
    flex-direction: row;
    flex: 1;
}

.cell_box {
    height: 110px;
    background-color: #fff;
}

.list {
    padding-bottom: 120px;
    background-color: #fff;
}

.item {
    height: 110px;
    padding: @padding_size;
    border-bottom-width: 1px;
    border-color: #eee;
    flex-direction: row;
    align-items: center;
}

.tb_hd {
    padding-left: @padding_size;
    padding-right: @padding_size;
    padding-top: 15px;
    padding-bottom: 15px;
    background-color: @bgf4f5f6;
}

.tb_td {}

.market_cap {
    width: 180px;
}

.coin_rank {
    width: 60px;
    justify-content: center;
}

.rank_text {
    width: 40px;
    height: 40px;
    line-height: 40px;
    background-color: #D6D6D6;
    border-radius: 6px;
    text-align: center;
    font-size: 20px;
    color: #fff;
}

.rank_one {
    background-color: #F9C76D;
}

.rank_two {
    background-color: #B5B5B5;
}

.rank_three {
    background-color: #CE8F66;
}

.coin_info {
    width: 210px;
}
.coin_name {
    flex-direction: row;
    align-items: center;
}

.coin_time {
    margin-left: 10px;
    font-size: 20px;
    color: #A2A4AB;
}

.coin_tag {
    margin-left: 10px;
    padding: 2px 5px;
    font-size: 20px;
    background-color: #358DFA;
    color: #fff;
    border-radius: 4px;
}

.coin_usd {
    font-size: 22px;
    color: #9B9DA4;
}
.coin_price {
    width: 240px;
}

.coin_change {
    width: 150px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 10px;
    padding-bottom: 10px;
    border-radius: 5px;
    text-align: center;
    color: #fff;
    font-size: 28px;
}

.text {
    font-size: 28px;
}

.warn {
    color: @warn_color;
}

.safe {
    color: @safe_color;
}

.icon_safe {
    color: @safe_color;
}

.icon_warn {
    margin-left: 10px;
    transform: rotate(180deg);
    color: @warn_color;
}

.tb_th {
    font-size: 24px;
    color: #9B9DA4;
}

.coin_box {
    flex-direction: row;
    align-items: center;
}

.coin_logo {
    width: 35px;
    height: 35px;
    border-radius: 50%;
}

.coin_text {
    padding-left: 15px;
}

.logo_image {
    width: 35px;
    height: 35px;
}

.coin_name {
    font-size: 22px;
    color: #9B9DA4;
    text-overflow: ellipsis;
    line: 1;
}

.cny_price_text {
    flex-direction: row;
    align-items: center;
}

.us_price_text {
    padding: 8px 0;
    font-size: 22px;
    color: #9B9DA4;
}

.coin_platform {
    font-size: 22px;
    color: #4883EE;
}

.coin_num {
    width: 200px;
}

.wrapper_scroller_box {
    width: 750px;
}

.wrapper_scroller {
    width: 750px;
    position: relative;
}

.scroller_box {
    width: 750px - 400px;
    position: absolute;
    left: 400px;
    top: 0;
}

.fixed_box {
    width: 400px;
    left: 0;
    top: 0;
    position: absolute;
}

.fixed_box_ios {
    position: relative;
}

.scroller_box_ios {
    position: relative;
}

</style>
