<template>
    <div class="container">
        <StatusBar></StatusBar>
        <wxc-minibar title="">
            <div class="bar_middle" slot="middle" @click="filterClick">
                <text class="bar_title">{{current_header.text || '榜单选币'}}</text>
                <text :class="['icon', 'bar_icon_arrow', bar_active && 'bar_icon_active']">&#xe90f;</text>
            </div>
            <div slot="right" @click="goSearchCoin">
                <text class="icon">&#xe915;</text>
            </div>
        </wxc-minibar>
        <wxc-popover ref="wxc-popover" coverColor="transparent" :hasArrow="false" :activeIndex="current_header.active_index" :buttons="popo_btns" :position="popoverPosition" @wxcPopoverButtonClicked="popoverButtonClicked" @wxcPopoverClosed="wxcPopoverClosed"></wxc-popover>
        <div class="content">
            <div class="tab_box">
                <wxc-tab-page ref="wxc-tab-page" :hasPageWrap="false" title-type="text" :tab-titles="tabTitles" :tab-styles="tabStyles" :tab-page-height="tabPageHeight" @wxcTabPageCurrentTabSelected="wxcTabPageCurrentTabSelected">
                </wxc-tab-page>
            </div>
            <div class="wrapper_scroller_box">
                <scroller class="wrapper_scroller" loadmoreoffset="600" @loadmore="loadmoreCoin" offset-accuracy="100" @scroll="scrollHandler" :style="{ height: page_height}" v-if="coin_list.length">
                    <!-- 左边 -->
                    <div :class="[!is_ios && 'fixed_box', is_ios && 'fixed_box_ios']" :style="{height: is_ios ? (table_height || page_height) : 'auto'}">
                        <div :class="[is_ios && 'fixed_box']" :style="{bottom: is_ios ? 0 : 'auto'}">
                            <div class="header">
                                <div class="header_list">
                                    <div :class="['header_item', header.class_name]" v-for="(header, i) in header_list" :key="i">
                                        <div class="header_title">
                                            <text class="title_text">{{header.name}}</text>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="list" ref="table_box">
                                <div class="cell_box" v-for="(coin, idnex) in coin_list" :key="idnex">
                                    <div class="item" @click="jumpCoinsDetail(coin)">
                                        <div class="tb_td coin_rank">
                                            <text :class="['rank_text', getRankClass(idnex+1)]">{{idnex+1}}</text>
                                        </div>
                                        <div class="tb_td coin_info">
                                            <text class="text">{{coin.symbol}}</text>
                                        </div>
                                        <div class="tb_td market_cap">
                                            <text :class="['text', 'cny_price_text']">{{String(coin.price_cny_str || '').replace('¥', '')}}</text>
                                            <text :class="['text', 'us_price_text']">={{String(coin.price_usd_str || '').replace('$', '') }} USD</text>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 右边 -->
                    <div :class="[!is_ios && 'scroller_box', is_ios && 'scroller_box_ios']" :style="{height: is_ios ? (table_height || page_height) : 'auto'}">
                        <div  :class="[is_ios && 'scroller_box']" :style="{bottom: is_ios ? 0 : 'auto',marginTop: is_ios ? -(table_height || page_height) : 'auto'}">
                            <scroller class="filter_scroller" scroll-direction="horizontal">
                                <div class="table_box">
                                    <div class="header">
                                        <div class="header_list">
                                            <div :class="['header_item', header.class_name]" v-for="(header, i) in table_head_list" :key="i">
                                                <div class="header_title">
                                                    <text class="title_text">{{header.name}}</text>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list" ref="table_box">
                                        <div class="cell_box" v-for="(coin, idnex) in coin_list" :key="idnex">
                                            <div class="item" @click="jumpCoinsDetail(coin)">
                                                <div class="tb_td coin_price" v-for="(table, i) in table_head_list" :key="i">
                                                    <text :class="['coin_change', coin[`percent_change_${current_header.key}`] > 0 ? 'safe_bg' : 'warn_bg']" v-if="table.name === '涨跌幅'">{{Number(coin[`percent_change_${current_header.key}`]).toFixed(2)}}%</text>
                                                    <text :class="['text', coin[table.key] > 0 ? 'safe' : 'warn']" v-else>{{String(coin[table.key_str] || '--').replace('¥', '')}}</text>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </scroller>
                        </div>
                    </div>
                </scroller>
            </div>
            <Loadmore :loading="loading.coin_list"></Loadmore>
        </div>
    </div>
</template>
<script>
import { Utils } from 'weex-ui';
import Refresher from '../components/Refresher.vue'
import WxcMinibar from '../components/WxcMinibar.vue'
import StatusBar from '../components/StatusBar.vue'
import Loadmore from '../components/Loadmore.vue'
import CoinItemInfo from '../components/CoinItemInfo.vue'
import WxcPopover from '../components/WxcPopover.vue'
import WxcTabPage from '../components/WxcTabPage.vue'
import {Iconfont} from '../config/config.js'
const dom = weex.requireModule('dom')
export default {
    components: { WxcTabPage, Refresher, WxcMinibar, StatusBar, Loadmore, CoinItemInfo, WxcPopover },
    data() {
        return {
            is_ios: weex.config.env.platform === 'iOS' ? true : false,
            loading: {
                coin_list: 'loading',
            },
            bar_active: false,
            coin_list: [],
            table_height: 0,
            popoverPosition: { x: 200, y: 520 },
            popoverArrowPosition: { pos: 'top', x: 160 },
            popo_btns: [{
                    text: '1小时',
                    active_index: 0,
                    key: '1h'
                },
                {
                    text: '24小时',
                    active_index: 1,
                    key: '24h'
                },
                {
                    text: '7天',
                    active_index: 2,
                    key: '7d'
                }
            ],
            percent_key: 'percent_change_1h',
            current_header: {},
            current_tab: {},
            header_list: [{
                name: '',
                active: false,
                class_name: 'coin_rank',
            }, {
                name: '币种',
                active: false,
                class_name: 'coin_info',
            }, {
                name: '最新价(CNY)',
                active: false,
                class_name: 'market_cap',
            }],
            table_head_list: [{
                name: '涨跌幅',
                class_name: 'coin_price',
                key: 'percent_change_24h',
                key_str: 'percent_change_24h_str',
                type: 'percent',
            }, {
                name: '成交额(CNY)',
                class_name: 'coin_price',
                key: 'volume_24h',
                key_str: 'volume_cny_24h_str',
                type: 'volume_cny',
            }, {
                name: '资金流入(CNY)',
                class_name: 'coin_price',
                key: 'coin_trade_cny',
                key_str: 'coin_trade_cny_str',
                type: 'coin_trade',
            }],
            tabTitles: [{
                    title: '涨幅榜',
                    key: 'percent_up',
                    type: 'percent',
                    width: 135,
                },
                {
                    title: '跌幅榜',
                    key: 'percent_down',
                    type: 'percent',
                    width: 135,
                },
                {
                    title: '成交额榜',
                    key: 'volume_cny',
                    type: 'volume_cny',
                    width: 170,
                },
                {
                    title: '资金流入榜',
                    key: 'coin_trade',
                    type: 'coin_trade',
                    width: 185,
                }
            ],
            tabStyles: {
                bgColor: '#FFFFFF',
                titleColor: '#434343',
                activeTitleColor: '#3D3D3D',
                activeBgColor: '#FFFFFF',
                isActiveTitleBold: true,
                height: 80,
                fontSize: 28,
                hasActiveBottom: true,
                activeBottomColor: '#F7B237',
                activeBottomHeight: 5,
                activeBottomWidth: 60,
                fontWeight: 'bold',
            },
            tabPageHeight: 80,
            coin_list_page: 1,
            coin_list_size: 20,
            router_params: {},
        }
    },
    beforeCreate() {
        var domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont2",
            'src': `url('${Iconfont}')`
        });
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.getRouterParams();
        },
        getRouterParams() {
            this.$router.getParams().then(resData => {
                this.router_params = resData;
                if (this.router_params.time) {
                    let btn = this.popo_btns.find(item => item.key === this.router_params.time);
                    btn = btn || this.popo_btns[0];
                    this.current_header = btn;
                } else {
                   this.current_header = this.$storage.getSync('top_seleCoin_bar_filters') || this.popo_btns[0] || {}; 
                }
                this.current_header.active_index = this.current_header.active_index || 0;
                this.initCurrentTab();
                this.getCoinsByRank();
            })
        },
        goSearchCoin() {
            this.$router.open({
                name: 'SearchCoin',
                params: {}
            })
        },
        filterClick(e) {
            this.bar_active = !this.bar_active;
            this.popoverPosition.x = e.position.x;
            this.popoverPosition.y = e.position.y + 55;
            this.$refs['wxc-popover'].wxcPopoverShow();
        },
        jumpCoinsDetail(coin) {
            this.$router.open({
                name: 'CoinDetail',
                type: 'PUSH',
                params: {
                    symbol: coin.symbol,
                    symbol_id: coin.id,
                }
            })
        },
        popoverButtonClicked(obj) {
            let index = obj.index;
            this.current_header = this.popo_btns[index];
            this.current_header.active_index = index;
            this.resetgetCoinsByRank();
            this.$storage.setSync('top_seleCoin_bar_filters', this.current_header); // 本地存储选择的过滤条件
        },
        wxcPopoverClosed() {
            this.bar_active = false;
        },
        scrollHandler(e) {
            if (!this.is_ios) {
                return;
            }
            dom.getComponentRect(this.$refs.table_box, option => {
                this.table_height = option.size.height/2 + 100;
            })
        },
        loadmoreCoin() {
            if (this.loading.coin_list !== 'loaded') {
                return;
            }
            this.coin_list_page++;
            this.getCoinsByRank();
        },
        wxcTabPageCurrentTabSelected(e) {
            let index = e.page;
            this.current_tab = this.tabTitles[index];
            this.setTableHeadList();
            this.resetgetCoinsByRank();

        },
        initCurrentTab() {
            for(let [index, tab] of this.tabTitles.entries()) {
                if (tab.key === this.router_params.tab_type) {
                    this.current_tab = this.tabTitles[index];
                    this.$refs['wxc-tab-page'].setPage(index,null,false);
                }
            }
        },
        setTableHeadList() {
            for (let item of this.table_head_list) {
                if (item.type === this.current_tab.type) {
                    this.table_head_list = this.table_head_list.filter((tab) => {
                        return item.type !== tab.type;
                    })
                    this.table_head_list.unshift(item)
                }
            }
        },
        resetgetCoinsByRank() {
            this.coin_list = [];
            this.coin_list_page = 1;
            this.getCoinsByRank();
        },
        getCoinsByRank() {
            let params = {};
            params.page = this.coin_list_page || 1;
            params.size = this.coin_list_size || 20;
            params.items = 1;
            params.time = this.current_header.key || '';
            params.order = '-1';
            params.rank = this.current_tab.key || 'percent_up';
            this.loading.coin_list = 'loading';
            this.$fetch({
                name: 'getCoinsByRank',
                methods: 'GET',
                data: params,
            }).then((res) => {
                if (res.error === 0) {
                    this.loading.coin_list = 'loaded';
                    if (params.page === 1) {
                        this.coin_list = res.items;
                        if (!res.items.length) {
                            this.loading.coin_list = 'empty';
                        }
                    } else {
                        if (!res.items.length) {
                            this.loading.coin_list = 'nomore';
                        } else {
                            this.coin_list.push(...res.items);
                        }
                    }
                } else {
                    this.loading.coin_list = 'error';
                    this.$notice.toast({ message: res.message })
                }
            }).catch((err) => {
                console.error(err);
            });
        },
        getRankClass(rank) {
            if (rank === 1) {
                return 'rank_one'
            } else if (rank === 2) {
                return 'rank_two'
            } else if (rank === 3) {
                return 'rank_three'
            } else {
                return ''
            }
        },
    },
    computed: {
        page_height() {
            return Utils.env.getPageHeight();
        },
    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.icon {
    color: #434343;
    font-family: iconfont2;
    font-size: 45px;
}

.bar_middle {
    flex-direction: row;
    align-items: center;
}

.bar_icon_arrow {
    margin-left: 10px;
    font-size: 15px;
    transform: rotate(180deg);
}

.bar_icon_active {
    transform: rotate(0);
}

.bar_title {
    font-size: 36px;
    font-weight: bold;
    color: #434343;
}

.header_list {
    flex-direction: row;
}

.header_item {
    padding: 28px 0;
}

.header_title {
    padding-left: @padding_size;
    align-items: center;
    flex-direction: row;
}

.header_refs {
    justify-content: flex-end;
}

.title_text {
    font-size: 24px;
    color: #9B9DA4;
}

.icon_arrow {
    padding-left: 10px;
    font-size: 15px;
}

.icon_refs {
    padding-right: 10px;
    font-size: 24px;
}

.filter_scroller {
    flex-direction: row;
    flex: 1;
}

.cell_box {
    height: 110px;
    background-color: #fff;
}

.list {
    padding-bottom: 120px;
    background-color: #fff;
}

.item {
    height: 110px;
    padding: @padding_size;
    border-bottom-width: 1px;
    border-color: #eee;
    flex-direction: row;
    align-items: center;
}

.tb_hd {
    padding-left: @padding_size;
    padding-right: @padding_size;
    padding-top: 15px;
    padding-bottom: 15px;
    background-color: @bgf4f5f6;
}

.tb_td {}

.market_cap {
    width: 180px;
}

.coin_rank {
    width: 60px;
    justify-content: center;
}

.rank_text {
    width: 40px;
    height: 40px;
    line-height: 40px;
    background-color: #D6D6D6;
    border-radius: 6px;
    text-align: center;
    font-size: 20px;
    color: #fff;
}

.rank_one {
    background-color: #F9C76D;
}

.rank_two {
    background-color: #B5B5B5;
}

.rank_three {
    background-color: #CE8F66;
}

.coin_info {
    width: 100px;
}

.coin_price {
    width: 260px;
}

.coin_change {
    width: 150px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 10px;
    padding-bottom: 10px;
    border-radius: 5px;
    text-align: center;
    color: #fff;
    font-size: 28px;
}

.warn_bg {
    background-color: @warn_color;
}

.safe_bg {
    background-color: @safe_color;
}

.text {
    font-size: 28px;
}

.warn {
    color: @warn_color;
}

.safe {
    color: @safe_color;
}

.icon_safe {
    color: @safe_color;
}

.icon_warn {
    margin-left: 10px;
    transform: rotate(180deg);
    color: @warn_color;
}

.tb_th {
    font-size: 24px;
    color: #9B9DA4;
}

.coin_box {
    flex-direction: row;
    align-items: center;
}

.coin_logo {
    width: 35px;
    height: 35px;
    border-radius: 50%;
}

.coin_text {
    padding-left: 15px;
}

.logo_image {
    width: 35px;
    height: 35px;
}

.coin_name {
    font-size: 22px;
    color: #9B9DA4;
    text-overflow: ellipsis;
    line: 1;
}

.cny_price_text {
    flex-direction: row;
    align-items: center;
}

.us_price_text {
    padding: 8px 0;
    font-size: 22px;
    color: #9B9DA4;
}

.coin_platform {
    font-size: 22px;
    color: #4883EE;
}

.coin_num {
    width: 200px;
}

.wrapper_scroller_box {
    width: 750px;
}

.wrapper_scroller {
    width: 750px;
    position: relative;
}

.scroller_box {
    width: 750px - 370px;
    position: absolute;
    left: 370px;
    top: 0;
}

.fixed_box {
    width: 370px;
    left: 0;
    top: 0;
    position: absolute;
}
.fixed_box_ios {
    position: relative;
}
.scroller_box_ios {
    position: relative;
}
</style>
