<template>
    <div class="container">
        <div v-if="!config_news.disable">
            <div class="less_row">
                <text class="icon icon_search" v-if="tabTitles.length === 1"></text>
                <bui-tabbar class="less_flex" style="background-color: #fff" :tabItems="tabTitles" @change="onItemChange" v-model="currentTabIndex" background="transparent" selectedBackground="transparent" :titleSize="32" :showSelectedLine="tabTitles.length > 1"></bui-tabbar>
                <text class="icon icon_search" @click="goSearchNews">&#xe915;</text>
            </div>
            <slider class="slider" @change="onSliderChange" :index="currentTabIndex" infinite="false">
                <!-- 快讯 -->
                <div class="slider-item">
                    <div class="isfixed" v-if="article_list.fast_article.length">
                        <div class="time">
                            <text class="icon time_icon">&#xe90d;</text>
                            <text class="day time_day">{{ filters.dateFormat(article_list.fast_article[timetag_i].publish_time / 1000, 'yyyy-MM-dd') }}</text>
                            <text class="day time_week">{{ filters.dateFormat(article_list.fast_article[timetag_i].publish_time / 1000, 'w') }}</text>
                            <text class="day time_today"> {{ filters.getDateNow(article_list.fast_article[timetag_i].publish_time) }}</text>
                        </div>
                    </div>
                    <list class="home_box" ref="fast_article" :show-scrollbar="true" offset-accuracy="100" loadmoreoffset="550" @loadmore="loadmoreFastArticleList" :style="{ height: (tabPageHeight) + 'px' }" @scroll="handleScroll">
                        <Refresher @refresh="refreshFastArticleList" @refreshEnd="refreshEnd" :loading="loading.fast_article"></Refresher>
                        <cell v-for="(article, index) in article_list.fast_article" :key="index" :index="index">
                            <div class="fast_new_box">
                                <!-- 头部的 时间格式显示 -->
                                <div class="time_tag" v-if="article.show_time_tag && index!=0" @appear="onappear(index)" @disappear="ondisappear(index)">
                                    <div class="time">
                                        <text class="icon time_icon">&#xe90d;</text>
                                        <text class="day time_day">{{ filters.dateFormat(article.publish_time / 1000, 'yyyy-MM-dd') }}</text>
                                        <text class="day time_week">{{ filters.dateFormat(article.publish_time / 1000, 'w') }}</text>
                                        <text class="day time_today"> {{ filters.getDateNow(article.publish_time) }}</text>
                                    </div>
                                </div>
                                <!-- 快讯 文章详情 -->
                                <FastNewItem :article="article" v-if="hackResetFast" @shareClick="shareClick"></FastNewItem>
                                <BetFloat type="betview" v-if="(index+1)%5==0 && show_bet_float" :tabberindex="(index-4)/5"></BetFloat>
                            </div>
                        </cell>
                        <cell>
                            <loadmore :loading="loading.fast_article"></loadmore>
                        </cell>
                        <cell class="tabbar_height"></cell>
                    </list>
                </div>
                <div class="slider-item">
                    <list class="home_box" ref="superior_article" :show-scrollbar="true" offset-accuracy="100" loadmoreoffset="550" @loadmore="loadmoreSuperiorArticleList" :style="{ height: (tabPageHeight) + 'px' }">
                        <Refresher @refresh="refreshSuperiorArticleList" @refreshEnd="refreshEnd" :loading="loading.superior_article"></Refresher>
                        <cell v-for="(article, index) in article_list.superior_article">
                            <ArticleItem :article="article"></ArticleItem>
                        </cell>
                        <cell>
                            <loadmore :loading="loading.superior_article"></loadmore>
                        </cell>
                        <cell class="tabbar_height"></cell>
                    </list>
                </div>
                <div class="slider-item">
                    <list class="home_box" ref="new_article" :show-scrollbar="true" offset-accuracy="100" loadmoreoffset="550" @loadmore="loadmoreNewArticleList" :style="{ height: (tabPageHeight) + 'px' }">
                        <Refresher @refresh="refreshNewArticleList" @refreshEnd="refreshEnd" :loading="loading.new_article"></Refresher>
                        <cell v-for="(article, index) in article_list.new_article" :key="index" :index="index">
                            <ArticleItem :article="article" :type="'newest'"></ArticleItem>
                        </cell>
                        <cell>
                            <loadmore :loading="loading.new_article"></loadmore>
                        </cell>
                        <cell class="tabbar_height"></cell>
                    </list>
                </div>
                <div class="slider-item">
                    <div class="isfixed" v-if="article_list.notice_article.length">
                        <div class="time">
                            <text class="icon time_icon">&#xe90d;</text>
                            <text class="day time_day">{{ filters.dateFormat(article_list.notice_article[noticetag_i].publish_time / 1000, 'yyyy-MM-dd') }}</text>
                            <text class="day time_week">{{ filters.dateFormat(article_list.notice_article[noticetag_i].publish_time / 1000, 'w') }}</text>
                            <text class="day time_today"> {{ filters.getDateNow(article_list.notice_article[noticetag_i].publish_time) }}</text>
                        </div>
                    </div>
                    <list class="home_box" ref="notice_article" :show-scrollbar="true" offset-accuracy="100" loadmoreoffset="550" @loadmore="loadmoreNoticeArticleList" :style="{ height: (tabPageHeight) + 'px' }" @scroll="handleScrollNotice">
                        <Refresher @refresh="refreshNoticeArticleList" @refreshEnd="refreshEnd" :loading="loading.notice_article"></Refresher>
                        <cell v-for="(article, index) in article_list.notice_article" :key="index" :index="index">
                            <div class="fast_new_box">
                                <div class="time_tag" v-if="article.show_time_tag && index!=0" @appear="onappearNotice(index)" @disappear="ondisappearNotice(index)">
                                    <div class="time">
                                        <text class="icon time_icon">&#xe90d;</text>
                                        <text class="day time_day">{{ filters.dateFormat(article.publish_time / 1000, 'yyyy-MM-dd') }}</text>
                                        <text class="day time_week">{{ filters.dateFormat(article.publish_time / 1000, 'w') }}</text>
                                        <text class="day time_today"> {{ filters.getDateNow(article.publish_time) }}</text>
                                    </div>
                                </div>
                                <FastNewItem :article="article" v-if="hackResetNotice" @shareClick="shareClick"></FastNewItem>
                            </div>
                        </cell>
                        <cell>
                            <loadmore :loading="loading.notice_article"></loadmore>
                        </cell>
                        <cell class="tabbar_height"></cell>
                    </list>
                </div>
                <div class="slider-item">
                    <list class="home_box" ref="weibo_article" :show-scrollbar="true" offset-accuracy="100" loadmoreoffset="550" @loadmore="loadmoreWeiboArticleList" :style="{ height: (tabPageHeight) + 'px' }">
                        <Refresher @refresh="refreshWeiboArticleList" @refreshEnd="refreshEnd" :loading="loading.weibo_article"></Refresher>
                        <cell v-for="(article, index) in article_list.weibo_article" :key="index" :index="index">
                            <div class="fast_new_box">
                                <WeiboItem :article="article"></WeiboItem>
                            </div>
                        </cell>
                        <cell>
                            <loadmore :loading="loading.weibo_article"></loadmore>
                        </cell>
                        <cell class="tabbar_height"></cell>
                    </list>
                </div>
                <div class="slider-item">
                    <list class="home_box" ref="primer_article" :show-scrollbar="true" offset-accuracy="100" loadmoreoffset="550" @loadmore="loadmorePrimerArticleList" :style="{ height: (tabPageHeight) + 'px' }">
                        <Refresher @refresh="refreshPrimerArticleList" @refreshEnd="refreshEnd" :loading="loading.primer_article"></Refresher>
                        <cell v-for="(article, index) in article_list.primer_article" :key="index" :index="index">
                            <ArticleItem :article="article"></ArticleItem>
                        </cell>
                        <cell>
                            <loadmore :loading="loading.primer_article"></loadmore>
                        </cell>
                        <cell class="tabbar_height"></cell>
                    </list>
                </div>
            </slider>
            <ArticleCapture :article="share_article" @getBash64Data="getBash64Data" v-if="show_capture" />
            <ShareComponents :showShare="show_capture" :shareConfigs="shareConfigs" @closeShare="closeShare" />
        </div>
        <div class="show_url" v-if="config_news.disable">
            <wxc-minibar :title="config_news.title" :useDefaultReturn="false">
                <div slot="left" @wxcMinibarLeftButtonClicked="wxcMinibarLeftButtonClicked"></div>
            </wxc-minibar>
            <web :src="config_news.data" :style="{ height: (tabPageHeight) + 'px' }" />
        </div>
    </div>
</template>
<script>
import BannerSlider from '../components/BannerSlider.vue'
import ArticleItem from '../components/ArticleItem.vue'
import FastNewItem from '../components/FastNewItem.vue'
import WeiboItem from '../components/WeiboItem.vue'
import Refresher from '../components/Refresher.vue'
import Loadmore from '../components/Loadmore.vue'
import BuiTabbar from '../components/BuiTabbar.vue'
import { Utils } from 'weex-ui'
import filters from '../config/filters.js'
import BetFloat from '../components/BetFloat.vue'
import common from '../config/common'
import WxcMinibar from '../components/WxcMinibar.vue'
import ArticleCapture from '../components/ArticleCapture.vue'
import ShareComponents from '../components/ShareComponents.vue'
export default {
    components: { BuiTabbar, BannerSlider, ArticleItem, FastNewItem, WeiboItem, Refresher, Loadmore, BetFloat, WxcMinibar, ArticleCapture, ShareComponents },
    data() {
        return {
            hideModule: this.$storage.getSync('hideModule') || {},
            filters,
            arr: [],
            currentTabIndex: 0,
            currentTab: {},
            tabPageHeight: 1334,
            loading: {
                superior_article: 'loading',
                new_article: 'loading',
                fast_article: 'loading',
                primer_article: 'loading',
                notice_article: 'loading',
                weibo_article: 'loading',
            },
            article_list: {
                superior_article: [],
                new_article: [],
                fast_article: [],
                primer_article: [],
                notice_article: [],
                weibo_article: [],
            },
            page: {
                superior_article: 1,
                new_article: 1,
                fast_article: 1,
                primer_article: 1,
                notice_article: 1,
                weibo_article: 1,
            },
            size: {
                superior_article: 15,
                new_article: 15,
                fast_article: 15,
                primer_article: 15,
                notice_article: 15,
                weibo_article: 15,
            },
            month_days: [],
            timetag_i: 0,
            tophidden: 'up',
            scrollnum: 0,
            noticetag_i: 0,
            noticetophidden: 'up',
            noticescrollnum: 0,
            config_news: {
                disable: 0,
            },
            hackResetFast: true,
            hackResetNotice: true,
            show_search: false,
            show_bet_float: false,
            share_article: {},
            show_capture: false,
            bash64Data: {},
        }
    },
    props: {
        tabbarActive: {
            type: Boolean,
            default: false
        },
    },
    watch: {
        'tabbarActive': {
            handler(newValue) {
                if (newValue) {
                    this.init();
                }
            },
            deep: true,
        },
    },
    created() {

    },
    methods: {
        init() {
            this.currentTab = this.tabTitles[this.currentTabIndex];
            this.initTabPage();
            this.getArticleData();
            this.getConfig();
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent(this.currentTab.event_type);
        },
        initTabPage() {
            this.tabPageHeight = Utils.env.getPageHeight();
        },
        shareClick(article) {
            this.show_capture = !this.show_capture;
            this.share_article = article;
        },
        closeShare() {
            this.bash64Data = {};
            this.show_capture = false;
        },
        getBash64Data(data) {
            this.bash64Data = data;
        },
        getConfig() {
            let params = {};
            params.type = 'app_config';
            params.key = 'app_func_switch';
            this.$fetch({
                name: 'getConfig',
                methods: 'GET',
                data: params,
            }).then((resData) => {
                if (resData.error === 0) {
                    resData.result = resData.result || {};
                    this.config_news = resData.result.news || {};
                }
            }).catch((err) => {
                console.error(err);
            });
        },
        onItemChange(index) {

        },
        onSliderChange(e) {
            var index = e.index;
            this.currentTab = this.tabTitles[e.index];
            this.currentTabIndex = index;
            this.getArticleData();
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent(this.currentTab.event_type);
        },
        loadmoreSuperiorArticleList() {
            if (this.loading.superior_article !== 'loaded') {
                return;
            }
            this.page.superior_article++;
            this.getSuperiorArticleList();
        },
        refreshSuperiorArticleList() {
            this.page.superior_article = 1;
            this.getSuperiorArticleList();
            this.$refs.superior_article.resetLoadmore(); // 滚动到列表末尾时将强制触发loadmore
        },
        loadmoreNewArticleList() {
            if (this.loading.new_article !== 'loaded') {
                return;
            }
            this.page.new_article++;
            this.getNewArticleList();
        },
        refreshNewArticleList() {
            this.page.new_article = 1;
            this.getNewArticleList();
            this.$refs.new_article.resetLoadmore();
        },
        loadmoreFastArticleList() {
            if (this.loading.fast_article !== 'loaded') {
                return;
            }
            this.page.fast_article++;
            this.getFastArticleList();
        },
        refreshFastArticleList() {
            this.show_bet_float = false; //刷新的时候防止竞猜的tab图闪烁
            this.page.fast_article = 1;
            this.month_days = [];
            this.timetag_i = 0;
            this.getFastArticleList();
            this.$refs.fast_article.resetLoadmore();
        },
        loadmorePrimerArticleList() {
            if (this.loading.primer_article !== 'loaded') {
                return;
            }
            this.page.primer_article++;
            this.getPrimerArticleList();
        },
        refreshPrimerArticleList() {
            this.page.primer_article = 1;
            this.getPrimerArticleList();
            this.$refs.primer_article.resetLoadmore();
        },
        loadmoreNoticeArticleList() {
            if (this.loading.notice_article !== 'loaded') {
                return;
            }
            this.page.notice_article++;
            this.getNoticeArticleList();
        },
        refreshNoticeArticleList() {
            this.page.notice_article = 1;
            this.month_days = [];
            this.noticetag_i = 0;
            this.getNoticeArticleList();
            this.$refs.notice_article.resetLoadmore();
        },
        loadmoreWeiboArticleList() {
            if (this.loading.weibo_article !== 'loaded') {
                return;
            }
            this.page.weibo_article++;
            this.getWeiboArticleList();
        },
        refreshWeiboArticleList() {
            this.page.weibo_article = 1;
            this.getWeiboArticleList();
            this.$refs.weibo_article.resetLoadmore();
        },

        jumpErosDemo() {
            this.$router.open({
                name: 'demo'
            })
        },
        getArticleData() {
            if (this.currentTab.type === 'superior') {
                if (!this.article_list.superior_article.length) {
                    this.getSuperiorArticleList();
                }
            }
            if (this.currentTab.type === 'new') {
                if (!this.article_list.new_article.length) {
                    this.getNewArticleList();
                }
            }
            if (this.currentTab.type === 'fast') {
                if (!this.article_list.fast_article.length) {
                    this.getFastArticleList();
                }
            }
            if (this.currentTab.type === 'primer') {
                if (!this.article_list.primer_article.length) {
                    this.getPrimerArticleList();
                }
            }
            if (this.currentTab.type === 'notice') {
                if (!this.article_list.notice_article.length) {
                    this.getNoticeArticleList();
                }
            }
            if (this.currentTab.type === 'weibo') {
                if (!this.article_list.weibo_article.length) {
                    this.getWeiboArticleList();
                }
            }
        },
        refreshEnd() {

        },
        getSuperiorArticleList() {
            let params = {};
            params.type = 'hot';
            params.quality = 'superior';
            params.page = this.page.superior_article || 1;
            params.size = this.size.superior_article || 15;
            if (params.page > 1) {
                params.ts = this.article_list.superior_article[0].download_time;
            }
            this.loading.superior_article = 'loading';
            this.$fetch({
                name: 'getArticleList',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.superior_article = 'loaded';
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.superior_article = 'nomore';
                        }
                        this.article_list.superior_article.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.superior_article = 'empty';
                        }
                        this.article_list.superior_article = resData.items;
                    }
                } else {
                    this.$notice.toast({ message: resData.message })
                }

            }).catch((e) => {
                this.loading.superior_article = 'error';
                console.log(e.message)
            });
        },
        getNewArticleList() {
            let params = {};
            params.type = 'hot';
            params.quality = '';
            params.page = this.page.new_article || 1;
            params.size = this.size.new_article || 15;
            if (params.page > 1) {
                params.ts = this.article_list.new_article[0].download_time;
            }
            this.loading.new_article = 'loading';
            this.$fetch({
                name: 'getArticleList',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.new_article = 'loaded';
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.new_article = 'nomore';
                        }
                        this.article_list.new_article.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.new_article = 'empty';
                        }
                        this.article_list.new_article = resData.items;
                    }
                } else {
                    this.$notice.toast({ message: resData.message })
                }

            }).catch((e) => {
                this.loading.new_article = 'error';
                console.log(e.message)
            });
        },
        getPrimerArticleList() {
            let params = {};
            params.type = 'hot';
            params.quality = 'primer';
            params.page = this.page.primer_article || 1;
            params.size = this.size.primer_article || 15;
            if (params.page > 1) {
                params.ts = this.article_list.primer_article[0].download_time;
            }
            this.loading.primer_article = 'loading';
            this.$fetch({
                name: 'getArticleList',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.primer_article = 'loaded';
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.primer_article = 'nomore';
                        }
                        this.article_list.primer_article.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.primer_article = 'empty';
                        }
                        this.article_list.primer_article = resData.items;
                    }
                } else {
                    this.$notice.toast({ message: resData.message })
                }

            }).catch((e) => {
                this.loading.primer_article = 'error';
                console.log(e.message)
            });
        },
        getFastArticleList() {
            let params = {};
            params.type = 'hot';
            params.quality = 'superior';
            params.page = this.page.fast_article || 1;
            params.size = this.size.fast_article || 15;
            params.event_type = 'fast_event';
            if (params.page > 1) {
                params.ts = this.article_list.fast_article[0].created_at;
            };
            this.loading.fast_article = 'loading';
            this.$fetch({
                name: 'getMessages',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.fast_article = 'loaded';
                    for (let item of resData.items) {
                        item.show_time_tag = this.isShowTimeTag(item);
                    }
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.fast_article = 'nomore';
                        }
                        this.article_list.fast_article.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.fast_article = 'empty';
                        }
                        this.article_list.fast_article = resData.items;
                        this.show_bet_float = true;
                        this.hackResetFast = false;
                        this.$nextTick(() => {
                            this.hackResetFast = true;
                        })
                    }
                } else {
                    this.$notice.toast({ message: resData.message })
                }

            }).catch((e) => {
                this.loading.fast_article = 'error';
                console.log(e.message)
            });
        },
        getWeiboArticleList() {
            let params = {};
            params.page = this.page.weibo_article || 1;
            params.size = this.size.weibo_article || 15;
            if (params.page > 1) {
                params.ts = this.article_list.weibo_article[0].created_at;
            };
            this.loading.weibo_article = 'loading';
            this.$fetch({
                name: 'getArticleWeibo',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.weibo_article = 'loaded';
                    for (let item of resData.items) {
                        item.show_time_tag = this.isShowTimeTag(item);
                    }
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.weibo_article = 'nomore';
                        }
                        this.article_list.weibo_article.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.weibo_article = 'empty';
                        }
                        this.article_list.weibo_article = resData.items;
                    }
                } else {
                    this.$notice.toast({ message: resData.message })
                }

            }).catch((e) => {
                this.loading.weibo_article = 'error';
                console.log(e.message)
            });
        },
        getNoticeArticleList() {
            let params = {};
            params.event_type = 'notice_event';
            params.page = this.page.notice_article || 1;
            params.size = this.size.notice_article || 15;
            if (params.page > 1) {
                params.ts = this.article_list.notice_article[0].created_at;
            };
            this.loading.notice_article = 'loading';
            this.$fetch({
                name: 'getMessages',
                method: 'GET',
                data: params
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.notice_article = 'loaded';
                    for (let item of resData.items) {
                        item.show_time_tag = this.isShowTimeTag(item);
                    }
                    if (params.page > 1) {
                        if (!resData.items.length) {
                            this.loading.notice_article = 'nomore';
                        }
                        this.article_list.notice_article.push(...resData.items);
                    } else {
                        if (!resData.items.length) {
                            this.loading.notice_article = 'empty';
                        }
                        this.article_list.notice_article = resData.items;
                        this.hackResetNotice = false;
                        this.$nextTick(() => {
                            this.hackResetNotice = true;
                        })
                    }
                } else {
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((e) => {
                this.loading.notice_article = 'error';
                console.log(e.message)
            });
        },
        isShowTimeTag(article) {
            let month_day = filters.dateFormat(article.publish_time / 1000, 'yyyy-MM-dd');
            let exists = !!this.month_days.find(m_d => m_d === month_day);
            if (!exists) {
                this.month_days.push(month_day);
            }
            return !exists;
        },
        handleScroll(e) {
            let contentOffset = e.contentOffset;
            let contentSize = e.contentSize;
            if (contentOffset.y < this.scrollnum) {
                this.tophidden = "up";
                this.scrollnum = contentOffset.y;
            } else {
                this.tophidden = "down";
                this.scrollnum = contentOffset.y;
            }
        },
        onappear(char) {
            if (this.tophidden == "up") {} else {
                if (this.timetag_i == 0) {
                    this.timetag_i = 0;
                } else {
                    this.timetag_i = char - 1;
                }
            }
        },
        ondisappear(char) {
            if (this.tophidden == "up") {
                this.timetag_i = char;
            } else {}
        },
        handleScrollNotice(e) {
            let contentOffset = e.contentOffset;
            let contentSize = e.contentSize;
            if (contentOffset.y < this.noticescrollnum) {
                this.noticetophidden = "up";
                this.noticescrollnum = contentOffset.y;
            } else {
                this.noticetophidden = "down";
                this.noticescrollnum = contentOffset.y;
            }
        },
        onappearNotice(char) {
            if (this.noticetophidden == "up") {} else {
                if (this.noticetag_i == 0) {
                    this.noticetag_i = 0;
                } else {
                    this.noticetag_i = char - 1;
                }
            }
        },
        ondisappearNotice(char) {
            if (this.noticetophidden == "up") {
                this.noticetag_i = char;
            } else {}
        },
        goSearchNews() {
            this.$router.open({
                name: 'SearchNews',
                params: {}
            })
        },
    },
    computed: {
        shareConfigs() {
            return {
                title: `${this.share_article.title}`, // 分享的标题
                content: `${this.share_article.text}`, // 分享的文字内容
                url: ``, // 分享对应的URL地址，如h5、音乐链接、视频链接、小程序的链接 http://i.test.bizhihui.vip  Token_Website
                image: `${this.bash64Data.bash64}`, // 分享的图片url,
                type: 'Image',
                imageInfo: this.bash64Data.imageInfo || {},
                imageType: 'base64'
            }
        },
        tabTitles () {
            let arr = []
            arr.push({
                title: '快讯',
                type: 'fast',
                event_type: 'bzh_news_quick',
            })
            if (!this.hideModule['NewsChosen']) arr.push({
                title: '精选',
                type: 'superior',
                event_type: 'bzh_news_chosen',
            })
            if (!this.hideModule['NewsNew']) arr.push({
                title: '最新',
                type: 'new',
                event_type: 'bzh_news_new',
            })
            if (!this.hideModule['NewsNotice']) arr.push({
                title: '公告',
                type: 'notice',
                event_type: 'bzh_news_notice',
            })
            if (!this.hideModule['NewsWeibo']) arr.push({
                title: '微博',
                type: 'weibo',
                event_type: 'bzh_news_weibo',
            })
            if (!this.hideModule['NewsTeach']) arr.push({
                title: '入门',
                type: 'primer',
                event_type: 'bzh_news_teach',
            })
            return arr
        },
    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.container {}

.isfixed {
    font-size: 28px;
    color: #8b919c;
    padding-top: 22px;
    padding-left: @padding_size;
    padding-bottom: 22px;
    background-color: @bgf4f5f6;
    border-width: 1px;
    border-color: #eee;
}

.home_box {
    position: relative;
    padding-bottom: @tabbar_height;
    width: 750px;
}

.content {
    position: relative;
    top: -70px;
}

.superior {
    top: -60px;
}

.border-cell {
    width: 750px;
    height: 24px;
    align-items: center;
    justify-content: center;
    border-bottom-width: 1px;
    border-style: solid;
    border-color: #eee;
}

.cell {
    background-color: #ffffff;
}

.icon {
    color: #333;
    font-family: iconfont2;
}

.time_tag {
    padding-top: 20px;
    padding-left: @padding_size;
    padding-bottom: 20px;
    background-color: @bgf4f5f6;
    border-width: 1px;
    border-color: #eee;
}

.time {
    flex-direction: row;
}

.time_icon {
    font-size: 24px;
    padding-right: 15px;
    color: #434343;
}

.day {
    font-size: 24px;
    padding-right: 15px;
    color: #434343;
}

text {
    display: inline;
}

.yi_text {
    color: #497ddb;
    font-size: 26px;
    margin-left: 10px;
}



// 搜索的样式
.icon_search {
    width: 90px;
    height: 96px;
    line-height: 96px;
    font-size: 45px;
    padding-left: 20px;
    font-weight: normal;
    color: #434343;
    background-color: #fff;
    border-bottom-color: #ddd;
    border-bottom-width: 1px;
}

</style>
