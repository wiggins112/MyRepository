<template>
    <div class="test">
        <div class="text">
            <text>Test</text>
            <text>Test</text>
        </div>
    </div>
</template>
<script>
let _self;
export default {
    data: function() {
        return {

        }
    },
    created() {
        _self = this;
        
    },
    methods: {

    },
    components: {

    }
}

</script>
<style scoped lang="less">
.test {
    margin-top: 200px;
}

</style>
