<template>
    <div class="EchartLine_box">
        <div class="line_hd">
            <div class="tabs">
                <text :class="['tab', tab.active && 'active']" @click="tabChart(tab)" v-for="tab in tab_items" :key="tab.name">{{tab.name}}</text>
            </div>
        </div>
        <div class="line_bd" :style="{width:750, height: line_height}">
            <bmchart v-if="loading.coin === 'loaded'" ref="chart" :options="$format(line_option)" :style="{width:750, height: line_height}" @finish='finish'></bmchart>
            <div class="loading_box" :style="{width: 750, height: line_height}" v-if="loading.coin !== 'loaded' || loading_echart">
                <Loadmore :loading="loading.coin" class="loading"></Loadmore>
            </div>
        </div>
    </div>
</template>
<script>
import filters from '../config/filters.js'
import { API_BaseUrl } from '../config/config.js'
import Loadmore from './Loadmore.vue'
export default {
    components: { Loadmore },
    data() {
        return {
            filters,
            line_option: {},
            tab_items: [{
                name: '1天',
                value: '',
                format: 'MM-dd hh:mm',
                active: true
            }, {
                name: '7天',
                value: '',
                format: 'yyyy-MM-dd',
                active: false
            }, {
                name: '1个月',
                value: '',
                format: 'yyyy-MM-dd',
                active: false
            }, {
                name: '1年',
                value: '',
                format: 'yyyy-MM-dd',
                active: false
            }, {
                name: '今年',
                value: '',
                format: 'yyyy-MM-dd',
                active: false
            }, {
                name: '所有',
                value: '',
                format: 'yyyy-MM-dd',
                active: false
            }],
            line_height: 350,
            current_tab: {
                format: 'MM-dd hh:mm',
            },
            router_params: {},
            loading: {
                coin: 'loading'
            },
            loading_echart: true,
        }
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.getRouterParams();
            this.current_tab = this.tab_items[0];
        },
        getRouterParams() {
            this.$router.getParams().then(resData => {
                this.router_params = resData;
                this.getCoinHistory();
            })
        },
        tabChart(tab) {
            for (let item of this.tab_items) {
                item.active = false;
            }
            tab.active = true;
            this.current_tab = tab;
            this.getCoinHistory();
            this.$emit('tabChart', tab)
        },
        finish() {
            this.loading_echart = false;
        },
        initEchartLine(result) {
            this.loading_echart = true;
            let xAis_time = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
            let data_series_line = [154, 1244, 2124, 412, 124, 214, 412, 3414, 624, 541, 351, 214];
            let data_series_bar = [10, 52, 200, 334, 390, 330, 412, 124, 214, 412, 3414, 624];
            xAis_time = [];
            data_series_line = [];
            data_series_bar = [];
            for (let item of result.price_usd) {
                xAis_time.push(this.filters.dateFormat(item[0] / 1000, (this.current_tab.format || 'MM-dd hh:mm') ))
                data_series_line.push(this.fixNumber(item[1]))
            }
            for (let item of result.volume_usd) {
                data_series_bar.push(item[1])
            }
            let max = parseInt(Math.max(...data_series_line));
            let min = parseInt(Math.min(...data_series_line));
            let max_volume_usd = Math.max(...data_series_bar);
            let volume_usd_unit = '';
            if (max_volume_usd > 100000000) {
                volume_usd_unit = '亿';
                data_series_bar = [];
                data_series_bar = result.volume_usd.map((item) => {
                    return item[1] / 100000000
                })
            }
            if (max_volume_usd < 100000000 && max_volume_usd >= 10000) {
                volume_usd_unit = '万';
                data_series_bar = [];
                data_series_bar = result.volume_usd.map((item) => {
                    return item[1] / 10000
                })
            }
            let option = {
                backgroundColor: '#ffffff',
                tooltip: {
                    trigger: 'axis',
                    backgroundColor: 'rgba(73,90,146, 0.7)',
                    textStyle: {
                        fontSize: 10,
                        color: '#fff'
                    },
                    padding: 5,
                    axisPointer: {
                        animation: false
                    },
                    formatter: function(params, ticket, callback) {
                        let str = '';
                        let time_str = '';
                        let items = params.sort(function(a, b) {
                            return (a.axisIndex - b.axisIndex)
                        });
                        for (let item of items) {
                            time_str = `${item.axisValue}<br />`;
                            str += `<span style="display: inline-block;margin-right: 5px;width: 7px;height: 7px;border-radius: 50%;background-color: ${item.color};"></span>${item.seriesName}：${item.value} USD<br />`
                        }
                        return time_str + str;
                    },
                    position: function(pos, params, dom, rect, size) {
                        // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                        var obj = { top: 25 };
                        obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                        return obj;
                    }
                },
                legend: {
                    data: ['价格（USD）', `24H成交额（${volume_usd_unit}）`],
                    top: 4,
                    right: 0,
                    itemWidth: 20,
                    itemHeight: 7,
                    textStyle: {
                        fontSize: 10,
                    }
                },
                axisPointer: {
                    link: { xAxisIndex: 'all' }
                },
                dataZoom: [{
                        type: 'inside',
                        show: true,
                        realtime: true,
                        start: 0,
                        // end: 100,
                        xAxisIndex: [0, 1],
                        bottom: '5%'
                    },
                    {
                        type: 'inside',
                        realtime: true,
                        start: 0,
                        // end: 100,
                        xAxisIndex: [0, 1],
                    }
                ],
                grid: [{
                    left: 0,
                    right: 0,
                    height: '40%',
                    top: 25,
                }, {
                    left: 0,
                    right: 0,
                    top: '53.7%',
                    height: '30%'
                }],
                xAxis: [{
                        show: false,
                        type: 'category',
                        axisLine: { onZero: true },
                        data: xAis_time
                    },
                    {
                        gridIndex: 1,
                        type: 'category',
                        axisLine: { onZero: true },
                        data: xAis_time,
                        position: 'bottom',
                        axisTick: {
                            show: false,
                            lineStyle: {
                                color: '#999'
                            }
                        },
                        axisLine: {
                            show: false,
                            lineStyle: {
                                color: '#999'
                            }
                        },
                        axisLabel: {
                            color: '#434343',
                            align: 'right'
                        },
                    }
                ],
                yAxis: [{
                        position: 'right',
                        scale: true,
                        zlevel: 1, // 使坐标数值最上层
                        axisLine: {
                            lineStyle: {
                                color: '#fff',
                            },
                        },
                        axisLabel: {
                            formatter: '{value}',
                            color: '#CC9A41',
                            fontSize: '10',
                            inside: true,
                        },
                        splitLine: {
                            lineStyle: {
                                color: 'rgba(249, 198, 121, 0.2)',
                                type: 'dashed',
                            }
                        }
                    },
                    {
                        scale: true,
                        gridIndex: 1,
                        splitNumber: 2,
                        zlevel: 1, // 使坐标数值最上层
                        axisLabel: {
                            show: true,
                            formatter: '{value} ' + volume_usd_unit,
                            fontSize: '10',
                            inside: true,
                        },
                        axisLine: { show: false },
                        axisTick: { show: false },
                        splitLine: {
                            show: false,
                            lineStyle: {
                                color: '#f7f7f7',
                                type: 'dashed',
                            }
                        }
                    }
                ],
                series: [{
                        name: '价格（USD）',
                        type: 'line',
                        smooth: true,
                        symbolSize: false,
                        itemStyle: {
                            normal: {
                                color: '#F7B642',
                            },
                        },
                        lineStyle: {
                            normal: {
                                width: 1.5,
                            }
                        },
                        areaStyle: {
                            normal: {
                                origin: 'end',
                                color: {
                                    type: 'linear',
                                    x: 1,
                                    y: 0,
                                    x2: 1,
                                    y2: 1,
                                    colorStops: [{
                                        offset: 0,
                                        color: this.filters.colorRgb('#FBD797', 0.5) // 0% 处的颜色
                                    }, {
                                        offset: 1,
                                        color: '#fff' // 100% 处的颜色
                                    }],
                                    globalCoord: false // 缺省为 false
                                }
                            }
                        },
                        data: data_series_line
                    },
                    {
                        name: `24H成交额（${volume_usd_unit}）`,
                        type: 'bar',
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        symbolSize: 8,
                        hoverAnimation: false,
                        itemStyle: {
                            normal: {
                                color: 'rgba(35,217,220,0.7)',
                            },
                        },
                        data: data_series_bar
                    }
                ]
            };
            this.line_option = option;
        },
        getCoinHistory() {
            let params = {};
            params.date = this.current_tab.name;
            this.loading.coin = 'loading';
            params.symbol = this.router_params.symbol;
            params.symbol_id = this.router_params.symbol_id;
            this.$fetch({
                url: `${API_BaseUrl}/api/coin/${params.symbol}/price_history`,
                method: 'GET',
                data: params,
            }).then(resData => {
                if (resData.error === 0) {
                    this.loading.coin = 'loaded';
                    if (!resData.result.price_usd || !resData.result.price_usd.length) {
                        this.loading.coin = 'empty';
                    } else {
                        this.initEchartLine(resData.result);
                    }
                } else {
                    this.loading.coin = 'error';
                    this.$notice.toast({ message: resData.message });
                }
            }).catch((e) => {
                this.loading.coin = 'error';
                console.log(e.message);
            });
        },
        fixNumber(number, num = 2) {
            if (Math.abs(number) < 1) {
                return number;
            }
            number = number || 0;
            let result = new Number(number).toFixed(num);
            result % 1 === 0 ? result = parseFloat(result) : result = result;
            return result;
        },
    }
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.icon {
    color: #9FA0A7;
    font-family: iconfont2;
    font-size: 24px;
}

.EchartLine_box {
    position: relative;
}

.line_bd {
    position: relative;
}

.line_hd {
    flex-direction: row;
    justify-content: space-between;
    height: 60px;
    border-bottom-width: 1px;
    border-color: #eee;
    background-color: #fff;
}

.tabs {
    flex-direction: row;
    margin-left: 28px;
}

.tab {
    flex: 1;
    line-height: 60px;
    margin-right: 80px;
    text-align: center;
    color: #333;
    font-size: 20px;
}

.tab:last-child {
    margin-right: 0;
}

.active {
    border-bottom-width: 3px;
    border-color: @main_color;
}

.loading_box {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 750px;
    margin: auto;
}

.loading {
    margin-top: 40px;
}

</style>
