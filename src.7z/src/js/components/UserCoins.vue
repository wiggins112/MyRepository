<template>
    <div class="user_coin_box">
        <div class="cell_box" v-if="user_coins.length">
            <div class="item tb_hd">
                <div class="tb_td name">
                    <text class="tb_th">币种</text>
                </div>
                <div class="tb_td price">
                    <text class="tb_th">价格(CNY)</text>
                </div>
                <div class="tb_td change">
                    <text class="tb_th">当日涨跌</text>
                </div>
            </div>
        </div>
        <div class="marketcap_box">
            <list ref="user_coins" :show-scrollbar="true" offset-accuracy="20" loadmoreoffset="550" @loadmore="loadmoreUserCoins" :style="{ height: (page_height) + 'px' }">
                <Refresher @refresh="refreshUserCoins" :loading="loading.user_coins"></Refresher>
                <cell class="cell_box" v-for="(coin, idnex) in user_coins">
                    <CoinItem :coin="coin"></CoinItem>
                </cell>
                <cell>
                    <Loadmore :loading="loading.user_coins" empty="您暂未添加自选哦~快去添加吧"></Loadmore>
                </cell>
                <cell>
                    <div class="add_box" @click="SetTabbarActive">
                        <div class="btn">
                            <text class="icon add_regular">&#xe916;</text>
                        </div>
                        <text class="add_text">添加自选</text>
                    </div>
                </cell>
                <cell class="fill_box"></cell>
            </list>
        </div>
        <Dialog title="" content="添加自选需要先登录哦，是否跳转至登录？" :show="dialog_show" :single="false" @wxcDialogCancelBtnClicked="DialogCancelClicked" @wxcDialogConfirmBtnClicked="DialogConfirmClicked">
        </Dialog>
    </div>
</template>
<script>
import { Utils } from 'weex-ui'
import Refresher from './Refresher.vue'
import Dialog from './Dialog.vue'
import Loadmore from './Loadmore.vue'
import CoinItem from './CoinItem.vue'
import common from '../config/common';

export default {
    components: {
        Refresher,
        Dialog,
        Loadmore,
        CoinItem
    },
    data() {
        return {
            loading: {
                coins: 'init',
                user_coins: 'init',
            },
            coins: [],
            user_coins: [],
            coins_page: 1,
            user_coins_page: 1,
            coins_size: 20,
            user_coins_size: 30,
            user_info: {},
            dialog_show: false,
        }
    },
    props: {
        Active: {
            type: Boolean,
            default: false,
        },
    },
    watch: {
        'Active': {
            handler(newValue) {
                if (newValue) {
                    this.init();
                }
            },
            deep: true,
        },
    },
    eros: {
        beforeBackAppear(params, options) {
            if (this.Active) {
                this.init();
            }
        },
    },
    created() {

    },
    methods: {
        init() {
            this.getUserInfo();
            if (this.user_info.is_login) {
                this.getUserCoins();
            }
        },
        getUserInfo() {
            this.user_info = this.$storage.getSync('user_info') || {};
        },
        loadmoreUserCoins() {
            return;
            if (this.loading.user_coins !== 'loaded') {
                return;
            }
            this.user_coins_page++;
            this.getUserCoins();
            this.$refs.user_coins.resetLoadmore(); // 滚动到列表末尾时将强制触发loadmore
        },
        refreshUserCoins() {
            this.user_coins_page = 1;
            this.getUserCoins();
        },
        getUserCoins() {
            let params = {};
            params.page = this.user_coins_page;
            params.size = this.user_coins_size;
            this.loading.user_coins = 'loading';
            this.$fetch({
                name: 'getUserCoins',
                methods: 'GET',
                data: params,
            }).then((res) => {
                if (res.error === 0) {
                    this.loading.user_coins = 'loaded';
                    if (params.page === 1) {
                        this.user_coins = res.items;
                        if (!res.items.length) {
                            this.loading.user_coins = 'empty';
                        }
                    } else {
                        if (!res.items.length) {
                            this.loading.user_coins = 'nomore';
                        } else {
                            this.user_coins.push(...res.items);
                        }
                    }
                } else {
                    if (res.error === 1) {
                        this.loading.user_coins = 'need_login';
                    } else {
                        this.loading.user_coins = 'error';
                    }
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((err) => {
                console.error(err);
            });
        },
        SetTabbarActive() {
            if (!this.user_info.is_login) {
                this.dialog_show = true;
                return;
            }
            this.$emit('SetTabbarActive', 2)
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent('bzh_chosen_market_add_click');
        },
        DialogConfirmClicked() {
            this.$router.open({
                name: 'Login',
            })
            this.dialog_show = false;
        },
        DialogCancelClicked() {
            this.dialog_show = false;
        },
    },
    computed: {
        page_height() {
            return Utils.env.getPageHeight();
        },
    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.icon {
    color: #9FA0A7;
    font-family: iconfont2;
    font-size: 26px;
}
.user_coin_box {
    width: 750px;
}
.cell_box {
    width: 750px;
    background-color: #fff;
}

.item {
    padding: @padding_size;
    border-bottom-width: 1px;
    border-color: #eee;
    flex-direction: row;
    align-items: center;
}

.tb_hd {
    padding-left: @padding_size;
    padding-right: @padding_size;
    padding-top: 15px;
    padding-bottom: 15px;
    background-color: @bgf4f5f6;
}

.tb_td {}

.rank {
    width: 120px;
}

.price {
    flex: 1;
}

.name {
    width: 220px;
}

.text {
    font-size: 28px;
}

.tb_th {
    font-size: 24px;
    color: #9B9DA4;
}

.coin_name {
    font-size: 22px;
    color: #9B9DA4;
}

.coin_usd {
    font-size: 22px;
    color: #9B9DA4;
}

.coin_change {
    width: 150px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 10px;
    padding-bottom: 10px;
    border-radius: 5px;
    text-align: center;
    color: #fff;
    font-size: 28px;
}


.fill_box {
    height: 250px;
}

.pair_symbol {
    flex-direction: row;
}

.pair_base {
    font-size: 22px;
    color: #9B9DA4;
}

.add_box {
    padding-top: 50px;
    padding-bottom: @tabbar_height + 90px;
    justify-content: center;
    align-items: center;
}

.btn {
    width: 88px;
    height: 88px;
    border-radius: 100%;
    background-color: #fff;
    justify-content: center;
    align-items: center;
}

.add_regular {
    font-size: 55px;
    color: #f7b237;
}

.add_text {
    font-size: 28px;
    margin-top: 20px;
}
</style>
