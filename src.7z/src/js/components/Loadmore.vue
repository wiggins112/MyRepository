<template>
    <div class="loadmore_wrap">
        <div class="loading_box" v-if="loading === 'loading'">
            <image class="loading_gif" resize="contain" :src="loading_gif"></image>
        </div>
        <div class="box nomore_box" v-if="loading === 'nomore'"><text class="text">{{nomore}}</text></div>
        <div class="box empty_box" v-if="loading === 'empty'"><text class="text">{{empty}}</text></div>
        <div class="box error_box" v-if="loading === 'neterror'"><text class="text">加载失败，请刷新重试</text></div>
        <div class="box error_box" v-if="loading === 'error'"><text class="text">加载出错了</text></div>
        <div class="box error_box" v-if="loading === 'need_login'"><text class="text">登录获取数据</text></div>
        <div class="box noloadmore" v-if="loading === 'noloadmore'"></div>
    </div>
</template>
<style scoped lang="less">
@import url('../css/veriable.less');
.loadmore_wrap {
    flex-direction: row;
    align-items: center;
    justify-content: center;
}

.box {
    padding-top: 20px;
    padding-bottom: 20px;
}
.indicator {
    margin-top: 16px;
    height: 40px;
    width: 40px;
    color: @main_color;
}
.text {
    font-size: 24px;
    color: #666;
}
.loading_gif {
    width: 120px;
    height: 120px;
}
</style>
<script>
export default {
    props: {
        loading: {
            type: String,
            default: 'loading',
        },
        empty: {
            type: String,
            default: '暂未收录',
        },
        nomore: {
            type: String,
            default: '没有更多了',
        },
    },
    data() {
        return {
            loading_gif: `bmlocal://assets/images/loading/loading_v2.gif`,
        }
    },
    methods: {
        
    }
}

</script>
