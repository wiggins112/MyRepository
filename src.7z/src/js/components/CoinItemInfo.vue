<template>
    <div class="coin_info_box">
        <div class="coin_logo">
            <image class="logo_image" resize="cover" :src="coin.icon || default_coin_icon"></image>
        </div>
        <div class="coin_text">
            <text class="text coin_symbol">{{coin.symbol}}</text>
            <text class="text coin_name">{{coin.name}}</text>
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {
            default_coin_icon: `bmlocal://assets/images/default_coin_icon.png`,
        }
    },
    props: {
        coin: {
            type: Object,
            required: true,
        },
    },
    created() {

    },
    methods: {
        
    }
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.icon {
    color: #9FA0A7;
    font-family: iconfont2;
    font-size: 24px;
}
.text {
    font-size: 28px;
}
.coin_info_box {
    flex-direction: row;
    align-items: center;
}
.coin_logo {
    width: 35px;
    height: 35px;
    border-radius: 50%;
}
.coin_text {
    flex: 1;
    padding-left: 15px;
    padding-right: 10px;
}
.logo_image {
    width: 35px;
    height: 35px;
}
.coin_symbol {
    font-size: 28px;
}
.coin_name {
    font-size: 22px;
    color: #9B9DA4;
    text-overflow: ellipsis;
    lines: 1;
}

</style>
