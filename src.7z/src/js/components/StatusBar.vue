<template>
    <div class="status_bar" :style="{'height': statusBarHeight, backgroundColor: statusBarStyle.bgColor}"></div>
</template>
<style scoped lang="less">
@import url('../css/veriable.less');
.status_bar {
    background-color: #ffffff;
}

</style>
<script>
export default {
    data() {
        return {
            statusBarHeight: weex.config.eros.statusBarHeight ? weex.config.eros.statusBarHeight : 40,
        }
    },
    props: {
        statusBarStyle: {
            type: Object,
            default: () => ({
                bgColor: '#ffffff',
            })
        },
    },
    methods: {

    }
}

</script>
