<template>
    <image style="width: 750px; height: 73px;" src="bmlocal://assets/images/listShadow.png" />
</template>

<script>
export default {
    name: 'ListShadow',
    data () {
        return {
        }
    }
}
</script>

<style scoped>
.listShadow {
    left: -25px;
    width: 750px;
    height: 73px;
}
</style>
