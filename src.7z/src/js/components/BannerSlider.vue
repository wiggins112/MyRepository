<template>
    <slider class="slider_box" :style="{width: imageWidth, height: imageHeight}" auto-play="true" interval="5000" @change="onchange" infinite="true">
        <div class="banner_item" v-for="img in banner_list" :style="{width: imageWidth, height: imageHeight}">
            <image class="image" :resize="imageResize" :src="img.image" :style="{width: imageWidth, height: imageHeight, borderRadius: imageRadius}" @click="openUrl(img)"></image>
        </div>
        <indicator class="indicator" :style="{width: imageWidth}" v-if="showIndicator && banner_list.length >= 2"></indicator>
    </slider>
</template>
<style scoped>
.iconfont {
    font-family: iconfont;
}

.image {
    width: 750px;
    height: 280px;
}

.slider_box {
    position: relative;
    width: 750px;
    height: 280px;
}

.banner_item {
    width: 750px;
    height: 280px;
}

.indicator {
    width: 750px;
    height: 40px;
    item-color: rgba(255, 255, 255, 0.5);
    item-selected-color: #ffffff;
    item-size: 10px;
    position: absolute;
    bottom: 8px;
    right: 0px;
}

</style>
<script>
import common from '../config/common';
export default {
    props: {
        banner_list: {
            type: Array,
            required: true,
        },
        bannerItemStyle: {
            type: String,
            default: ''
        },
        showIndicator: {
            type: Boolean,
            default: true
        },
        imageResize: {
            type: String,
            default: 'cover'
        },
        imageWidth: {
            type: String,
            default: '750px'
        },
        imageHeight: {
            type: String,
            default: '280px'
        },
        imageRadius: {
            type: String,
            default: '0'
        },
    },
    data() {
        return {
            user_info: {},
        }
    },
    create() {
        this.init();
    },
    methods: {
        getUserInfo() {
            this.user_info = this.$storage.getSync('user_info') || {};
        },
        onchange(event) {
            this.$emit('onchange', event);
        },
        openUrl(banner) {
            this.getUserInfo();
            if (!banner.link) {
                return;
            }
            if (banner.type === 'app_page') {
                if (!this.user_info.token && banner.link === "AirdropETHH5") { //若是h5且没有登录的话  跳去登录页   
                    this.$router.open({
                        name: 'Login',
                    })
                } else {
                    this.$router.open({
                        name: banner.link,
                        type: 'PUSH',
                        params: banner.link_params || {},
                    })
                }
            } else {
                this.$router.toWebView({
                    url: banner.link, // 页面 url
                    title: '币智慧', // 页面 title
                    navShow: true // 是否显示native端导航栏，默认是true
                })
            }
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent(banner.event_name || 'banner');
        },
    }
}

</script>
