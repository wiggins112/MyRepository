<template>
    <div class="slider-item">
        <div class="bd_list" v-for="(mess,mess_i) in messages">
            <CellItem class="cellitem" :has-arrow="true" @wxcCellClicked="goMore(mess)" :has-top-border="false" title="" :hasVerticalIndent="false" titleIconSize="40" extraContent="更多" titlecolor="red">
                <div slot="title" class="less_row" @click="showList(mess_i)">
                    <text :class="['icon',(mess.open)?'cell_left_downicon':'cell_left_upicon']">&#xe925</text>
                    <text class="cell_left_text">{{mess.cn}}</text>
                </div>
            </CellItem>
            <div class="cell_box" v-if="mess.open && mess.items.length>0">
                <div class="item tb_hd">
                    <div class="tb_td name">
                        <text class="tb_th">{{mess.menus[0].cn}}</text>
                    </div>
                    <div class="tb_td price">
                        <text class="tb_th">{{mess.menus[1].cn}}</text>
                    </div>
                    <div class="tb_td change">
                        <text class="tb_th">{{mess.menus[2].cn}}</text>
                    </div>
                </div>
            </div>
            <div class="cell_item" v-for="(coin, index)  in mess.items" :key="index" v-if="mess.open">
                <CoinItemRank :coin="coin">
                    <div slot="price_slot">
                        <text class="text">{{String(coin.price_cny_str || '').replace('¥', '')}}</text>
                        <text class="text coin_usd"> ={{String(coin.price_usd_str || '').replace('$', '')}} USD</text>
                    </div>
                    <div slot="change_bt">
                        <text v-if="mess.field === 'percent_change_24h_str'" :class="['coin_change', coin.percent_change_24h > 0 ? 'safe_bg' : 'warn_bg']">{{coin.percent_change_24h_str}}</text>
                        <text v-if="mess.field === 'volume_cny_24h_str'" class="coin_change safe">{{String(coin.volume_cny_24h_str || '').replace('¥', '')}}</text>
                        <text v-if="mess.field === 'coin_trade_cny_24h_str'" class="coin_change safe">{{String(coin.coin_trade_cny_24h_str || '').replace('¥', '')}}</text>
                    </div>
                </CoinItemRank>
            </div>
        </div>
    </div>
</template>
<script>
import CoinItemRank from '../components/CoinItemRank.vue'
import CellItem from '../components/CellItem.vue'
import common from '../config/common';
export default {
    components: {
        CoinItemRank,
        CellItem,
    },
    data() {
        return {
            messages: [],
            user_coins: [],
        }
    },
    props: {
        refresh: {
            type: Boolean,
            default: false,
        }
    },
    watch: {
        async refresh(value) {
            if (value) {
                await this.getCoinsByRanks();
                this.$emit('refreshEnd');
            }
        }
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.getCoinsByRanks();
        },
        showList(i) {
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent('bzh_market_list');
            this.messages[i].open = !this.messages[i].open;
        },
        goMore({name,time}) {
            // 友盟统计-自定义事件计数
            common.addUmengClickEvent('bzh_market_list');
            this.$router.open({
                name: 'TopSeleCoin',
                params: {
                    tab_type: name,
                    time,
                }
            })
        },
        getCoinsByRanks(type) {
            let params = {};
            params.size = 6;
            return this.$fetch({
                name: 'getCoinsByRanks',
                methods: 'GET',
                data: params,
            }).then((resData) => {
                if (resData.error === 0) {
                    this.messages = resData.items;
                } else {
                    this.$notice.toast({ message: resData.message })
                }
            }).catch((err) => {
                console.error(err);
            });
        }

    },
}

</script>
<style scoped lang="less">
@import url('../css/veriable.less');
.icon {
    font-family: iconfont2;
    font-size: 15px;
    margin: 20px 0;
}

.less_row {
    padding: 25px 0;
}

.bd_list {
    margin-bottom: 25px;
}

.cell_item {
    width: 750px;
    background-color: #fff;
}

.cell_left {
    padding: 25px;
    flex: 4;
    flex-direction: row;
}

.cell_left_text {
    color: #333333;
    font-size: 30px;
    padding-left: 15px;
}

.cell_left_upicon {
    color: #9b9fa5;
    margin: 5px;
    font-size: 25px;
    transform: rotate(-90deg);
}

.cell_left_downicon {
    color: #9b9fa5;
    margin: 5px;
    font-size: 25px;
    transform: rotate(0deg);
}


// 列表的表头
.cell_box {
    width: 750px;
    background-color: #fff;
}

.item {
    padding: @padding_size;
    border-bottom-width: 1px;
    border-color: #eee;
    flex-direction: row;
    align-items: center;
}


.rank {
    width: 120px;
}

.price {
    flex: 1;
}

.name {
    padding-left: 15px;
    width: 260px;
}

.text {
    font-size: 28px;
}

.tb_th {
    font-size: 24px;
    color: #9B9DA4;
}
.coin_change {
    width: 160px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 10px;
    padding-bottom: 10px;
    border-radius: 5px;
    text-align: center;
    color: #fff;
    font-size: 28px;
}
.coin_usd {
    font-size: 22px;
    color: #9B9DA4;
}
.safe {
    text-align: right;
}

</style>
